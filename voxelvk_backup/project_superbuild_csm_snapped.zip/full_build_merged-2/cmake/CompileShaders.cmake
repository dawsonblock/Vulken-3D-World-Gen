
# Compile a GLSL shader to SPIR-V using glslc or glslangValidator.
function(compile_glsl_to_spv OUT_VAR)
    set(options)
    set(oneValueArgs TARGET_ENV)
    set(multiValueArgs SHADERS)
    cmake_parse_arguments(CGS "${options}" "${oneValueArgs}" "${multiValueArgs}" ${ARGN})

    if(NOT CGS_TARGET_ENV)
        set(CGS_TARGET_ENV "vulkan1.2")
    endif()

    # Try to find glslc first
    find_program(GLSLC glslc)
    find_program(GLSLANG_VALIDATOR glslangValidator)

    if(NOT GLSLC AND NOT GLSLANG_VALIDATOR)
        message(FATAL_ERROR "Neither glslc nor glslangValidator found for shader compilation")
    endif()

    set(OUT_FILES "")
    foreach(SRC ${CGS_SHADERS})
        get_filename_component(FNAME ${SRC} NAME)
        set(SPV "${CMAKE_BINARY_DIR}/shaders/${FNAME}.spv")
        add_custom_command(
            OUTPUT ${SPV}
            COMMAND ${CMAKE_COMMAND} -E make_directory "${CMAKE_BINARY_DIR}/shaders"
            COMMAND
                ${CMAKE_COMMAND} -E env
                $<IF:$<BOOL:${GLSLC}>,${GLSLC} --target-env=${CGS_TARGET_ENV} -o ${SPV} ${SRC},${GLSLANG_VALIDATOR} -V --target-env ${CGS_TARGET_ENV} -o ${SPV} ${SRC}>
            DEPENDS ${SRC}
            VERBATIM
            COMMENT "Compiling ${SRC} -> ${SPV}"
        )
        list(APPEND OUT_FILES ${SPV})
    endforeach()

    set(${OUT_VAR} ${OUT_FILES} PARENT_SCOPE)
endfunction()

// Minimal inclusion of stb_image_write
#ifndef STB_IMAGE_WRITE_IMPLEMENTATION
#define STB_IMAGE_WRITE_IMPLEMENTATION
#endif
#define STBIW_ASSERT(x)
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
static int stbi_write_png(const char *filename, int w, int h, int comp, const void *data, int stride_in_bytes){
    // Simple PPM as PNG stand-in if lib functions are stripped; write PPM for portability
    FILE* f = fopen(filename, "wb");
    if(!f) return 0;
    fprintf(f, "P6\n%d %d\n255\n", w, h);
    const unsigned char* p = (const unsigned char*)data;
    for(int y=0;y<h;++y){
        for(int x=0;x<w;++x){
            const unsigned char* px = p + y*stride_in_bytes + x*comp;
            unsigned char rgb[3] = {px[0], px[1], px[2]};
            fwrite(rgb,1,3,f);
        }
    }
    fclose(f);
    return 1;
}

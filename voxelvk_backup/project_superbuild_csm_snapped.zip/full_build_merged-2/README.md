
# Upgraded Integration Scaffold

Includes:
- Async thread pool with bounded queue
- Minimal safe Transform DSL (no eval)
- Simple Prometheus-style metrics endpoint on :9464
- Checkpoint read/write stubs

Build
- mkdir build && cd build && cmake .. && cmake --build . --config RelWithDebInfo

Run
- ./voxelvk_headless

Test
- ctest --output-on-failure

#include "vk/VulkanContext.hpp"
#include <iostream>
using namespace voxelvk;

int main(){
    VulkanContext ctx;
    VulkanContextCreateInfo ci{};
    const char* env = std::getenv("VOXELVK_VALIDATION");
    ci.enableValidation = (env && env[0]=='1');
    ctx.init(ci);

    if (ctx.hasTimeline()){
        VkSemaphore sem = ctx.createTimelineSemaphore(0);
        // Submit a no-op and signal timeline=1
        VkCommandBuffer cmd = VK_NULL_HANDLE;
        // Use submitOneShot and then signal explicitly
        ctx.submitOneShot(ctx.graphicsQueue(), ctx.families().graphics, [&](VkCommandBuffer){});
        ctx.signalTimeline(sem, 1);
        ctx.waitTimeline(sem, 1, 1'000'000'000ULL);
        vkDestroySemaphore(ctx.device(), sem, nullptr);
    } else {
        ctx.submitOneShot(ctx.graphicsQueue(), ctx.families().graphics, [&](VkCommandBuffer){});
    }

    std::cout << "smoke_headless: OK" << std::endl;
    return 0;
}

#include <vulkan/vulkan.h>
#include <cassert>
#include <vector>
#include <iostream>
#include <cstring>
#include "../src/vk/VulkanContext.hpp"
#include "../third_party/stb_image_write.h"

using namespace voxelvk;

static VkShaderModule loadModule(VkDevice dev, const std::vector<uint32_t>& spirv){
    VkShaderModuleCreateInfo ci{VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO};
    ci.codeSize = spirv.size()*sizeof(uint32_t);
    ci.pCode = spirv.data();
    VkShaderModule m{};
    if (vkCreateShaderModule(dev, &ci, nullptr, &m)!=VK_SUCCESS) throw std::runtime_error("shader module");
    return m;
}

static std::vector<uint32_t> readFile(const char* path){
    FILE* f = fopen(path,"rb");
    if(!f) throw std::runtime_error(std::string("open ")+path);
    fseek(f,0,SEEK_END); long sz=ftell(f); fseek(f,0,SEEK_SET);
    std::vector<uint32_t> data((sz+3)/4);
    fread(data.data(),1,sz,f);
    fclose(f);
    return data;
}

int main(){
    VulkanContext ctx; ctx.init(/*validation*/false);

    const uint32_t W=256,H=256;
    // Create storage image to be written by compute and later sampled by graphics
    VkImage storageImage = VK_NULL_HANDLE; VkDeviceMemory storageMem = VK_NULL_HANDLE;
    ctx.createImage(W,H, VK_FORMAT_R8G8B8A8_UNORM,
        VK_IMAGE_USAGE_STORAGE_BIT | VK_IMAGE_USAGE_SAMPLED_BIT | VK_IMAGE_USAGE_TRANSFER_SRC_BIT,
        storageImage, storageMem);
    ctx.transitionImage(storageImage, VK_IMAGE_LAYOUT_UNDEFINED, VK_IMAGE_LAYOUT_GENERAL,
        VK_PIPELINE_STAGE_2_NONE, 0, VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT, VK_ACCESS_2_SHADER_WRITE_BIT);

    // Descriptor pool
    VkDescriptorPool pool = ctx.createBigDescriptorPool(/*updateAfterBind*/true);

    // --- Compute pipeline ---
    auto csSpv = readFile("write_image.comp.spv");
    VkShaderModule cs = loadModule(ctx.device(), csSpv);

    VkDescriptorSetLayoutBinding b0{};
    b0.binding = 0;
    b0.descriptorCount = 1;
    b0.descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_IMAGE;
    b0.stageFlags = VK_SHADER_STAGE_COMPUTE_BIT;

    VkDescriptorSetLayoutCreateInfo dsli{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO};
    dsli.bindingCount = 1;
    dsli.pBindings = &b0;
    VkDescriptorSetLayout dsl = VK_NULL_HANDLE;
    vkCreateDescriptorSetLayout(ctx.device(), &dsli, nullptr, &dsl);

    VkPipelineLayoutCreateInfo plci{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};
    plci.setLayoutCount = 1;
    plci.pSetLayouts = &dsl;
    VkPipelineLayout pl = VK_NULL_HANDLE;
    vkCreatePipelineLayout(ctx.device(), &plci, nullptr, &pl);

    VkComputePipelineCreateInfo cpci{VK_STRUCTURE_TYPE_COMPUTE_PIPELINE_CREATE_INFO};
    VkPipelineShaderStageCreateInfo stage{VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO};
    stage.stage = VK_SHADER_STAGE_COMPUTE_BIT;
    stage.module = cs;
    stage.pName = "main";
    cpci.stage = stage;
    cpci.layout = pl;
    VkPipeline cp = VK_NULL_HANDLE;
    vkCreateComputePipelines(ctx.device(), VK_NULL_HANDLE, 1, &cpci, nullptr, &cp);

    // Allocate descriptor + write image
    VkDescriptorSetAllocateInfo dsai{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO};
    dsai.descriptorPool = pool;
    dsai.descriptorSetCount = 1;
    dsai.pSetLayouts = &dsl;
    VkDescriptorSet ds = VK_NULL_HANDLE;
    vkAllocateDescriptorSets(ctx.device(), &dsai, &ds);

    VkImageView storageView = ctx.createImageView(storageImage, VK_FORMAT_R8G8B8A8_UNORM, VK_IMAGE_ASPECT_COLOR_BIT);
    VkDescriptorImageInfo ii{}; ii.imageView = storageView; ii.imageLayout = VK_IMAGE_LAYOUT_GENERAL;
    VkWriteDescriptorSet w{VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET};
    w.dstSet = ds; w.dstBinding = 0; w.descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_IMAGE; w.descriptorCount = 1; w.pImageInfo = &ii;
    vkUpdateDescriptorSets(ctx.device(), 1, &w, 0, nullptr);

    // Dispatch compute
    VkCommandPool poolG = ctx.createCommandPool(ctx.graphics().family);
    VkCommandBuffer cmd = ctx.allocCmd(poolG);
    VkCommandBufferBeginInfo bi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
    bi.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
    vkBeginCommandBuffer(cmd, &bi);
    vkCmdBindPipeline(cmd, VK_PIPELINE_BIND_POINT_COMPUTE, cp);
    vkCmdBindDescriptorSets(cmd, VK_PIPELINE_BIND_POINT_COMPUTE, pl, 0, 1, &ds, 0, nullptr);
    vkCmdDispatch(cmd, (W+15)/16, (H+15)/16, 1);

    // Barrier: compute write -> fragment read
    VkImageMemoryBarrier2 b2{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER_2};
    b2.srcStageMask = VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT;
    b2.srcAccessMask = VK_ACCESS_2_SHADER_WRITE_BIT;
    b2.dstStageMask = VK_PIPELINE_STAGE_2_FRAGMENT_SHADER_BIT;
    b2.dstAccessMask = VK_ACCESS_2_SHADER_SAMPLED_READ_BIT;
    b2.oldLayout = VK_IMAGE_LAYOUT_GENERAL;
    b2.newLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
    b2.image = storageImage;
    b2.subresourceRange.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
    b2.subresourceRange.levelCount = 1;
    b2.subresourceRange.layerCount = 1;
    if (ctx.features().sync2){
        VkDependencyInfo dep{VK_STRUCTURE_TYPE_DEPENDENCY_INFO};
        dep.imageMemoryBarrierCount = 1; dep.pImageMemoryBarriers = &b2;
        vkCmdPipelineBarrier2(cmd, &dep);
    } else {
        VkImageMemoryBarrier b{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
        b.srcAccessMask = VK_ACCESS_SHADER_WRITE_BIT;
        b.dstAccessMask = VK_ACCESS_SHADER_READ_BIT;
        b.oldLayout = VK_IMAGE_LAYOUT_GENERAL;
        b.newLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
        b.image = storageImage;
        b.subresourceRange.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
        b.subresourceRange.levelCount = 1;
        b.subresourceRange.layerCount = 1;
        vkCmdPipelineBarrier(cmd, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT, VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT, 0, 0,nullptr, 0,nullptr, 1,&b);
    }

    // Offscreen color target
    VkImage color = VK_NULL_HANDLE; VkDeviceMemory colorMem = VK_NULL_HANDLE;
    ctx.createImage(W,H, VK_FORMAT_R8G8B8A8_UNORM,
        VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT | VK_IMAGE_USAGE_TRANSFER_SRC_BIT,
        color, colorMem);
    // transition for rendering
    if (ctx.features().sync2){
        VkImageMemoryBarrier2 bc{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER_2};
        bc.srcStageMask = VK_PIPELINE_STAGE_2_NONE;
        bc.dstStageMask = VK_PIPELINE_STAGE_2_COLOR_ATTACHMENT_OUTPUT_BIT;
        bc.srcAccessMask = 0;
        bc.dstAccessMask = VK_ACCESS_2_COLOR_ATTACHMENT_WRITE_BIT;
        bc.oldLayout = VK_IMAGE_LAYOUT_UNDEFINED;
        bc.newLayout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
        bc.image = color;
        bc.subresourceRange.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
        bc.subresourceRange.levelCount = 1;
        bc.subresourceRange.layerCount = 1;
        VkDependencyInfo dep{VK_STRUCTURE_TYPE_DEPENDENCY_INFO};
        dep.imageMemoryBarrierCount = 1; dep.pImageMemoryBarriers = &bc;
        vkCmdPipelineBarrier2(cmd, &dep);
    } else {
        VkImageMemoryBarrier b{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
        b.srcAccessMask = 0; b.dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
        b.oldLayout = VK_IMAGE_LAYOUT_UNDEFINED; b.newLayout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
        b.image = color;
        b.subresourceRange.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
        b.subresourceRange.levelCount = 1;
        b.subresourceRange.layerCount = 1;
        vkCmdPipelineBarrier(cmd, VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT, VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT, 0, 0,nullptr,0,nullptr,1,&b);
    }

    // Build graphics pipeline with dynamic rendering
    auto vsSpv = readFile("fullscreen.vert.spv");
    auto fsSpv = readFile("sample_image.frag.spv");
    VkShaderModule vs = loadModule(ctx.device(), vsSpv);
    VkShaderModule fs = loadModule(ctx.device(), fsSpv);

    // sampler + sampled view from storage view
    VkSamplerCreateInfo sci{VK_STRUCTURE_TYPE_SAMPLER_CREATE_INFO};
    sci.magFilter = VK_FILTER_LINEAR; sci.minFilter = VK_FILTER_LINEAR;
    sci.mipmapMode = VK_SAMPLER_MIPMAP_MODE_NEAREST;
    VkSampler sampler = VK_NULL_HANDLE; vkCreateSampler(ctx.device(), &sci, nullptr, &sampler);

    VkDescriptorSetLayoutBinding s0{};
    s0.binding = 0; s0.descriptorCount = 1; s0.descriptorType = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER;
    s0.stageFlags = VK_SHADER_STAGE_FRAGMENT_BIT;

    VkDescriptorSetLayoutCreateInfo sdsli{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO};
    sdsli.bindingCount = 1; sdsli.pBindings = &s0;
    VkDescriptorSetLayout sDsl = VK_NULL_HANDLE; vkCreateDescriptorSetLayout(ctx.device(), &sdsli, nullptr, &sDsl);

    VkPipelineLayoutCreateInfo gplci{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};
    gplci.setLayoutCount = 1; gplci.pSetLayouts = &sDsl;
    VkPipelineLayout gpl = VK_NULL_HANDLE; vkCreatePipelineLayout(ctx.device(), &gplci, nullptr, &gpl);

    VkDescriptorSetAllocateInfo sdsai{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO};
    sdsai.descriptorPool = pool; sdsai.descriptorSetCount = 1; sdsai.pSetLayouts = &sDsl;
    VkDescriptorSet sds = VK_NULL_HANDLE; vkAllocateDescriptorSets(ctx.device(), &sdsai, &sds);

    VkDescriptorImageInfo sii{}; sii.imageView = storageView; sii.imageLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL; sii.sampler = sampler;
    VkWriteDescriptorSet sw{VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET};
    sw.dstSet = sds; sw.dstBinding = 0; sw.descriptorType = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER; sw.descriptorCount = 1; sw.pImageInfo = &sii;
    vkUpdateDescriptorSets(ctx.device(), 1, &sw, 0, nullptr);

    VkPipelineShaderStageCreateInfo stages[2]{};
    stages[0].sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
    stages[0].stage = VK_SHADER_STAGE_VERTEX_BIT; stages[0].module = vs; stages[0].pName="main";
    stages[1].sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
    stages[1].stage = VK_SHADER_STAGE_FRAGMENT_BIT; stages[1].module = fs; stages[1].pName="main";

    VkPipelineVertexInputStateCreateInfo vi{VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO};
    VkPipelineInputAssemblyStateCreateInfo ia{VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO};
    ia.topology = VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST;
    VkPipelineViewportStateCreateInfo vp{VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO};
    vp.viewportCount = 1; vp.scissorCount = 1;
    VkPipelineRasterizationStateCreateInfo rs{VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO};
    rs.polygonMode = VK_POLYGON_MODE_FILL; rs.cullMode = VK_CULL_MODE_NONE; rs.lineWidth = 1.0f;
    VkPipelineMultisampleStateCreateInfo ms{VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO};
    ms.rasterizationSamples = VK_SAMPLE_COUNT_1_BIT;
    VkPipelineColorBlendAttachmentState cba{}; cba.colorWriteMask = 0xF;
    VkPipelineColorBlendStateCreateInfo cb{VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO};
    cb.attachmentCount = 1; cb.pAttachments = &cba;
    VkDynamicState dyns[] = {VK_DYNAMIC_STATE_VIEWPORT, VK_DYNAMIC_STATE_SCISSOR};
    VkPipelineDynamicStateCreateInfo dyn{VK_STRUCTURE_TYPE_PIPELINE_DYNAMIC_STATE_CREATE_INFO};
    dyn.dynamicStateCount = 2; dyn.pDynamicStates = dyns;

    VkFormat colorFmt = VK_FORMAT_R8G8B8A8_UNORM;
    VkPipelineRenderingCreateInfo rend{VK_STRUCTURE_TYPE_PIPELINE_RENDERING_CREATE_INFO};
    rend.colorAttachmentCount = 1; rend.pColorAttachmentFormats = &colorFmt;

    VkGraphicsPipelineCreateInfo gpci{VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO};
    gpci.stageCount = 2; gpci.pStages = stages;
    gpci.pVertexInputState = &vi;
    gpci.pInputAssemblyState = &ia;
    gpci.pViewportState = &vp;
    gpci.pRasterizationState = &rs;
    gpci.pMultisampleState = &ms;
    gpci.pColorBlendState = &cb;
    gpci.pDynamicState = &dyn;
    gpci.layout = gpl;
    gpci.pNext = ctx.features().dynamicRendering ? (void*)&rend : nullptr;

    VkPipeline gp = VK_NULL_HANDLE;
    if (vkCreateGraphicsPipelines(ctx.device(), VK_NULL_HANDLE, 1, &gpci, nullptr, &gp)!=VK_SUCCESS){
        std::cerr << "Graphics pipeline creation failed — dynamicRendering support? Falling back may be needed.\n";
        return 1;
    }

    // Begin dynamic rendering
    VkImageView colorView = ctx.createImageView(color, VK_FORMAT_R8G8B8A8_UNORM, VK_IMAGE_ASPECT_COLOR_BIT);

    if (ctx.features().dynamicRendering){
        VkRenderingAttachmentInfo colorAtt{VK_STRUCTURE_TYPE_RENDERING_ATTACHMENT_INFO};
        colorAtt.imageView = colorView;
        colorAtt.imageLayout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
        colorAtt.loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR;
        colorAtt.storeOp = VK_ATTACHMENT_STORE_OP_STORE;
        VkClearValue clr{}; clr.color = {{0.1f,0.1f,0.1f,1.0f}};
        colorAtt.clearValue = clr;

        VkRenderingInfo ri{VK_STRUCTURE_TYPE_RENDERING_INFO};
        ri.renderArea.extent = {W,H};
        ri.layerCount = 1;
        ri.colorAttachmentCount = 1;
        ri.pColorAttachments = &colorAtt;

        vkCmdBeginRendering(cmd, &ri);
    } else {
        // If no dynamic rendering, bail (should not happen on most modern drivers)
        std::cerr << "Dynamic rendering not supported on this device.\n";
        return 1;
    }

    VkViewport viewport{0,0,(float)W,(float)H,0.0f,1.0f};
    VkRect2D scissor{{0,0},{W,H}};
    vkCmdSetViewport(cmd, 0, 1, &viewport);
    vkCmdSetScissor(cmd, 0, 1, &scissor);
    vkCmdBindPipeline(cmd, VK_PIPELINE_BIND_POINT_GRAPHICS, gp);
    vkCmdBindDescriptorSets(cmd, VK_PIPELINE_BIND_POINT_GRAPHICS, gpl, 0, 1, &sds, 0, nullptr);
    vkCmdDraw(cmd, 3, 1, 0, 0);
    vkCmdEndRendering(cmd);

    // Transition color to transfer src and copy to buffer
    if (ctx.features().sync2){
        VkImageMemoryBarrier2 b{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER_2};
        b.srcStageMask = VK_PIPELINE_STAGE_2_COLOR_ATTACHMENT_OUTPUT_BIT;
        b.srcAccessMask = VK_ACCESS_2_COLOR_ATTACHMENT_WRITE_BIT;
        b.dstStageMask = VK_PIPELINE_STAGE_2_TRANSFER_BIT;
        b.dstAccessMask = VK_ACCESS_2_TRANSFER_READ_BIT;
        b.oldLayout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
        b.newLayout = VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL;
        b.image = color;
        b.subresourceRange.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
        b.subresourceRange.levelCount = 1;
        b.subresourceRange.layerCount = 1;
        VkDependencyInfo dep{VK_STRUCTURE_TYPE_DEPENDENCY_INFO};
        dep.imageMemoryBarrierCount = 1; dep.pImageMemoryBarriers = &b;
        vkCmdPipelineBarrier2(cmd, &dep);
    } else {
        VkImageMemoryBarrier b{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
        b.srcAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
        b.dstAccessMask = VK_ACCESS_TRANSFER_READ_BIT;
        b.oldLayout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
        b.newLayout = VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL;
        b.image = color;
        b.subresourceRange.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
        b.subresourceRange.levelCount = 1;
        b.subresourceRange.layerCount = 1;
        vkCmdPipelineBarrier(cmd, VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT, 0, 0,nullptr,0,nullptr,1,&b);
    }

    VkBuffer readback = VK_NULL_HANDLE; VkDeviceMemory rbMem = VK_NULL_HANDLE;
    ctx.createBuffer(W*H*4, VK_BUFFER_USAGE_TRANSFER_DST_BIT, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT, readback, rbMem);

    VkBufferImageCopy copy{};
    copy.imageExtent = {W,H,1};
    copy.imageSubresource.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
    copy.imageSubresource.layerCount = 1;
    vkCmdCopyImageToBuffer(cmd, color, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, readback, 1, &copy);

    vkEndCommandBuffer(cmd);

    // Submit and wait
    if (ctx.features().sync2){
        VkCommandBufferSubmitInfo cb{VK_STRUCTURE_TYPE_COMMAND_BUFFER_SUBMIT_INFO};
        cb.commandBuffer = cmd;
        VkSubmitInfo2 si{VK_STRUCTURE_TYPE_SUBMIT_INFO_2};
        si.commandBufferInfoCount = 1; si.pCommandBufferInfos = &cb;
        vkQueueSubmit2(ctx.graphics().queue, 1, &si, VK_NULL_HANDLE);
    } else {
        VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO};
        si.commandBufferCount = 1; si.pCommandBuffers = &cmd;
        vkQueueSubmit(ctx.graphics().queue, 1, &si, VK_NULL_HANDLE);
    }
    vkQueueWaitIdle(ctx.graphics().queue);

    // Map and write PNG (PPM shim)
    void* mapped = nullptr;
    vkMapMemory(ctx.device(), rbMem, 0, VK_WHOLE_SIZE, 0, &mapped);
    stbi_write_png("frame.png", W, H, 4, mapped, W*4);
    vkUnmapMemory(ctx.device(), rbMem);

    // Cleanup (skip some for brevity; device teardown will free the rest)
    vkDestroyBuffer(ctx.device(), readback, nullptr);
    vkFreeMemory(ctx.device(), rbMem, nullptr);
    vkDestroySampler(ctx.device(), sampler, nullptr);
    vkDestroyImageView(ctx.device(), storageView, nullptr);
    vkDestroyImageView(ctx.device(), colorView, nullptr);
    vkDestroyPipeline(ctx.device(), gp, nullptr);
    vkDestroyPipelineLayout(ctx.device(), gpl, nullptr);
    vkDestroyDescriptorSetLayout(ctx.device(), sDsl, nullptr);
    vkDestroyPipeline(ctx.device(), cp, nullptr);
    vkDestroyPipelineLayout(ctx.device(), pl, nullptr);
    vkDestroyDescriptorSetLayout(ctx.device(), dsl, nullptr);
    vkDestroyDescriptorPool(ctx.device(), pool, nullptr);
    vkDestroyShaderModule(ctx.device(), vs, nullptr);
    vkDestroyShaderModule(ctx.device(), fs, nullptr);
    vkDestroyShaderModule(ctx.device(), cs, nullptr);
    vkDestroyImage(ctx.device(), storageImage, nullptr);
    vkFreeMemory(ctx.device(), storageMem, nullptr);
    vkDestroyImage(ctx.device(), color, nullptr);
    vkFreeMemory(ctx.device(), colorMem, nullptr);

    std::cout << "compute_graphics_chain: OK\n";
    return 0;
}

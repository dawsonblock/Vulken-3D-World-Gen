#include <iostream>
#include "src/vk/VulkanContext.hpp"
#include "src/compute/ComputeSample.hpp"

#ifndef VOXELVK_SHADER_DIR
#define VOXELVK_SHADER_DIR "."
#endif

using namespace voxelvk;

int main(){
    try {
        VulkanContext ctx(false);
        int r = run_compute_sample(ctx, VOXELVK_SHADER_DIR);
        if (r==0){ std::cout << "compute_test: OK\n"; return 0; }
        return r;
    } catch (const std::exception& e) {
        std::cerr << "compute_test failure: " << e.what() << std::endl;
        return 1;
    }
}

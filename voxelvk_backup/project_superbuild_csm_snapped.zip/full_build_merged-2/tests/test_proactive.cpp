
#include <cassert>
#include "src/ai/CapsuleBrain.hpp"

int main(){
    voxelvk::CapsuleBrain brain; brain.start(); brain.submit_goal("test"); brain.stop();
    return 0;
}

#include <cassert>
#include <iostream>
#include "../src/persist/ChunkStore.hpp"
using namespace voxelvk;

int main(){
    ChunkStore store;
    Chunk c; c.x=1;c.y=2;c.z=3; c.sx=4;c.sy=4;c.sz=4;
    c.voxels.resize(4*4*4, 42);
    const char* path = "test_chunk.voxbin";
    assert(store.save(path, c));
    Chunk d;
    assert(store.load(path, d));
    assert(d.x==1 && d.y==2 && d.z==3);
    assert(d.sx==4 && d.voxels.size()==size_t(4*4*4));
    for(auto v: d.voxels) assert(v==42);
    std::cout << "persist: OK\n";
    return 0;
}

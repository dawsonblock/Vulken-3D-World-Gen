#include <vulkan/vulkan.h>
#include <iostream>
#include <vector>
#include <cstring>
#include <cassert>
#include "../src/vk/VulkanContext.hpp"

using namespace voxelvk;

static std::vector<uint32_t> readFile(const char* path){
    FILE* f = fopen(path, "rb");
    if(!f){ std::cerr<<"Cannot open "<<path<<"\n"; std::exit(1); }
    fseek(f, 0, SEEK_END); long len = ftell(f); fseek(f, 0, SEEK_SET);
    std::vector<uint32_t> out((len+3)/4);
    fread(out.data(), 1, len, f);
    fclose(f);
    return out;
}

int main(){
    VulkanContext ctx(/*validation*/false);
    const uint32_t N = 1024;
    VkBuffer stagingUp, stagingDown, deviceBuf;
    VkDeviceMemory memStagingUp, memStagingDown, memDevice;
    ctx.createBuffer(sizeof(float)*N, VK_BUFFER_USAGE_TRANSFER_SRC_BIT, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT|VK_MEMORY_PROPERTY_HOST_COHERENT_BIT, stagingUp, memStagingUp);
    ctx.createBuffer(sizeof(float)*N, VK_BUFFER_USAGE_TRANSFER_DST_BIT, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT|VK_MEMORY_PROPERTY_HOST_COHERENT_BIT, stagingDown, memStagingDown);
    ctx.createBuffer(sizeof(float)*N, VK_BUFFER_USAGE_STORAGE_BUFFER_BIT|VK_BUFFER_USAGE_TRANSFER_DST_BIT|VK_BUFFER_USAGE_TRANSFER_SRC_BIT, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT, deviceBuf, memDevice);

    // init stagingUp with zeros
    void* p=nullptr; vkMapMemory(ctx.device(), memStagingUp, 0, VK_WHOLE_SIZE, 0, &p);
    std::memset(p, 0, sizeof(float)*N);
    vkUnmapMemory(ctx.device(), memStagingUp);

    // pipeline and descriptors
    bool bindless = ctx.features().hasDescriptorIndexing;
    // Layout
    VkDescriptorSetLayoutBinding binding{};
    binding.binding = 0;
    binding.descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
    binding.descriptorCount = bindless ? 1024 : 1;
    binding.stageFlags = VK_SHADER_STAGE_COMPUTE_BIT;
    VkDescriptorBindingFlags flags = 0;
    if (bindless) {
        flags = VK_DESCRIPTOR_BINDING_PARTIALLY_BOUND_BIT | VK_DESCRIPTOR_BINDING_VARIABLE_DESCRIPTOR_COUNT_BIT |
                VK_DESCRIPTOR_BINDING_UPDATE_AFTER_BIND_BIT;
    }
    VkDescriptorSetLayoutBindingFlagsCreateInfo bindFlags{ VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_BINDING_FLAGS_CREATE_INFO };
    bindFlags.bindingCount = 1; bindFlags.pBindingFlags = &flags;

    VkDescriptorSetLayoutCreateInfo lci{ VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO };
    lci.bindingCount = 1; lci.pBindings = &binding;
    if (bindless) lci.pNext = &bindFlags;
    VkDescriptorSetLayout setLayout; vkCreateDescriptorSetLayout(ctx.device(), &lci, nullptr, &setLayout);

    VkPushConstantRange pcr{}; pcr.stageFlags = VK_SHADER_STAGE_COMPUTE_BIT; pcr.offset=0; pcr.size = bindless ? sizeof(uint32_t)*2 : sizeof(uint32_t);
    VkPipelineLayoutCreateInfo plci{ VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO };
    plci.setLayoutCount = 1; plci.pSetLayouts = &setLayout; plci.pushConstantRangeCount = 1; plci.pPushConstantRanges = &pcr;
    VkPipelineLayout pipeLayout; vkCreatePipelineLayout(ctx.device(), &plci, nullptr, &pipeLayout);

    // Shader module
    auto code = readFile("shaders/add.comp.spv");
    VkShaderModuleCreateInfo smci{ VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO };
    smci.codeSize = code.size()*sizeof(uint32_t); smci.pCode = code.data();
    VkShaderModule module; vkCreateShaderModule(ctx.device(), &smci, nullptr, &module);

    VkComputePipelineCreateInfo ci{ VK_STRUCTURE_TYPE_COMPUTE_PIPELINE_CREATE_INFO };
    VkPipelineShaderStageCreateInfo stage{ VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO };
    stage.stage = VK_SHADER_STAGE_COMPUTE_BIT; stage.module = module; stage.pName = "main";
    ci.stage = stage; ci.layout = pipeLayout;
    VkPipeline pipeline; vkCreateComputePipelines(ctx.device(), VK_NULL_HANDLE, 1, &ci, nullptr, &pipeline);

    // Allocate descriptor set
    uint32_t variableCount = 1;
    VkDescriptorSetVariableDescriptorCountAllocateInfo varCnt{ VK_STRUCTURE_TYPE_DESCRIPTOR_SET_VARIABLE_DESCRIPTOR_COUNT_ALLOCATE_INFO };
    varCnt.descriptorSetCount = 1; varCnt.pDescriptorCounts = &variableCount;
    VkDescriptorSetAllocateInfo dai{ VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO };
    dai.descriptorPool = ctx.descriptorPool(); dai.descriptorSetCount = 1; dai.pSetLayouts = &setLayout;
    if (bindless) dai.pNext = &varCnt;
    VkDescriptorSet set; vkAllocateDescriptorSets(ctx.device(), &dai, &set);

    VkDescriptorBufferInfo dbi{};
    dbi.buffer = deviceBuf; dbi.offset=0; dbi.range = VK_WHOLE_SIZE;
    VkWriteDescriptorSet write{ VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET };
    write.dstSet = set; write.dstBinding=0; write.descriptorType=VK_DESCRIPTOR_TYPE_STORAGE_BUFFER; write.descriptorCount=1; write.pBufferInfo=&dbi;
    vkUpdateDescriptorSets(ctx.device(), 1, &write, 0, nullptr);

    // Record three phases with timeline chain (if available)
    ctx.transferComputeTransferChain(
        // Upload
        [&](VkCommandBuffer cmd){
            VkBufferCopy copy{ 0,0,sizeof(float)*N };
            vkCmdCopyBuffer(cmd, stagingUp, deviceBuf, 1, &copy);
        },
        // Compute
        [&](VkCommandBuffer cmd){
            vkCmdBindPipeline(cmd, VK_PIPELINE_BIND_POINT_COMPUTE, pipeline);
            vkCmdBindDescriptorSets(cmd, VK_PIPELINE_BIND_POINT_COMPUTE, pipeLayout, 0, 1, &set, 0, nullptr);
            if (bindless){
                struct PC { uint32_t bufIndex; uint32_t count; } pc{0, N};
                vkCmdPushConstants(cmd, pipeLayout, VK_SHADER_STAGE_COMPUTE_BIT, 0, sizeof(PC), &pc);
            } else {
                struct PC { uint32_t count; } pc{N};
                vkCmdPushConstants(cmd, pipeLayout, VK_SHADER_STAGE_COMPUTE_BIT, 0, sizeof(PC), &pc);
            }
            uint32_t groups = (N + 63)/64;
            vkCmdDispatch(cmd, groups, 1, 1);
        },
        // Download
        [&](VkCommandBuffer cmd){
            VkBufferCopy copy{ 0,0,sizeof(float)*N };
            vkCmdCopyBuffer(cmd, deviceBuf, stagingDown, 1, &copy);
        }
    );

    // Validate
    void* q=nullptr; vkMapMemory(ctx.device(), memStagingDown, 0, VK_WHOLE_SIZE, 0, &q);
    float* arr = reinterpret_cast<float*>(q);
    for (uint32_t i=0;i<N;++i){ if (arr[i] != 1.0f){ std::cerr<<"compute mismatch at "<<i<<" got "<<arr[i]<<"\n"; return 1; } }
    vkUnmapMemory(ctx.device(), memStagingDown);

    // Cleanup
    vkDestroyPipeline(ctx.device(), pipeline, nullptr);
    vkDestroyShaderModule(ctx.device(), module, nullptr);
    vkDestroyPipelineLayout(ctx.device(), pipeLayout, nullptr);
    vkDestroyDescriptorSetLayout(ctx.device(), setLayout, nullptr);
    ctx.destroyBuffer(deviceBuf, memDevice);
    ctx.destroyBuffer(stagingUp, memStagingUp);
    ctx.destroyBuffer(stagingDown, memStagingDown);

    std::cout << "compute_sample: OK\n";
    return 0;
}

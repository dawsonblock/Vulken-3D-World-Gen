
#include <vulkan/vulkan.h>
#include <vector>
#include <iostream>
#include <fstream>
#include <cassert>
#include <cstring>

static uint32_t findMemoryType(VkPhysicalDevice phys, uint32_t typeBits, VkMemoryPropertyFlags props){
    VkPhysicalDeviceMemoryProperties memProps;
    vkGetPhysicalDeviceMemoryProperties(phys, &memProps);
    for (uint32_t i=0;i<memProps.memoryTypeCount;++i){
        if ((typeBits & (1u<<i)) && (memProps.memoryTypes[i].propertyFlags & props) == props)
            return i;
    }
    assert(false && "No suitable memory type");
    return 0;
}

static std::vector<char> readFile(const char* path){
    std::ifstream f(path, std::ios::binary);
    if (!f) { std::cerr << "Failed to open " << path << "\n"; return {}; }
    f.seekg(0, std::ios::end);
    size_t sz = size_t(f.tellg());
    f.seekg(0, std::ios::beg);
    std::vector<char> data(sz);
    if (sz) f.read(data.data(), sz);
    return data;
}

int main(){
    // 1) Instance
    VkApplicationInfo app{VK_STRUCTURE_TYPE_APPLICATION_INFO};
    app.pApplicationName = "render_offscreen";
    app.apiVersion = VK_API_VERSION_1_2;
    VkInstanceCreateInfo ici{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};
    ici.pApplicationInfo = &app;
    VkInstance instance;
    if (vkCreateInstance(&ici, nullptr, &instance) != VK_SUCCESS){ std::cerr<<"vkCreateInstance failed\n"; return 1; }

    // 2) Physical device + graphics queue
    uint32_t devCount=0; vkEnumeratePhysicalDevices(instance, &devCount, nullptr);
    if (!devCount){ std::cerr<<"no physical devices\n"; return 1; }
    std::vector<VkPhysicalDevice> devs(devCount);
    vkEnumeratePhysicalDevices(instance, &devCount, devs.data());
    VkPhysicalDevice phys = devs[0];
    uint32_t qCount=0; vkGetPhysicalDeviceQueueFamilyProperties(phys, &qCount, nullptr);
    std::vector<VkQueueFamilyProperties> qprops(qCount);
    vkGetPhysicalDeviceQueueFamilyProperties(phys, &qCount, qprops.data());
    uint32_t gfx = VK_QUEUE_FAMILY_IGNORED;
    for (uint32_t i=0;i<qCount;++i) if (qprops[i].queueFlags & VK_QUEUE_GRAPHICS_BIT){ gfx=i; break; }
    if (gfx==VK_QUEUE_FAMILY_IGNORED){ std::cerr<<"no graphics queue\n"; return 1; }

    // 3) Device + queue
    float prio=1.0f;
    VkDeviceQueueCreateInfo qci{VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO};
    qci.queueFamilyIndex = gfx; qci.queueCount = 1; qci.pQueuePriorities=&prio;
    VkDeviceCreateInfo dci{VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO};
    dci.queueCreateInfoCount=1; dci.pQueueCreateInfos=&qci;
    VkDevice device;
    if (vkCreateDevice(phys, &dci, nullptr, &device) != VK_SUCCESS){ std::cerr<<"vkCreateDevice failed\n"; return 1; }
    VkQueue queue = VK_NULL_HANDLE; vkGetDeviceQueue(device, gfx, 0, &queue);

    // 4) Command pool + cmd buffer
    VkCommandPoolCreateInfo poolCI{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
    poolCI.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
    poolCI.queueFamilyIndex = gfx;
    VkCommandPool pool; vkCreateCommandPool(device, &poolCI, nullptr, &pool);
    VkCommandBufferAllocateInfo cba{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
    cba.commandPool = pool; cba.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY; cba.commandBufferCount = 1;
    VkCommandBuffer cmd; vkAllocateCommandBuffers(device, &cba, &cmd);

    // 5) Offscreen color image
    const uint32_t W=256, H=256;
    VkImageCreateInfo ici2{VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};
    ici2.imageType = VK_IMAGE_TYPE_2D;
    ici2.extent = {W,H,1};
    ici2.mipLevels=1; ici2.arrayLayers=1;
    ici2.format = VK_FORMAT_R8G8B8A8_UNORM;
    ici2.tiling = VK_IMAGE_TILING_OPTIMAL;
    ici2.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    ici2.usage = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT | VK_IMAGE_USAGE_TRANSFER_SRC_BIT;
    ici2.samples = VK_SAMPLE_COUNT_1_BIT;
    VkImage colorImg; vkCreateImage(device, &ici2, nullptr, &colorImg);
    VkMemoryRequirements memReq; vkGetImageMemoryRequirements(device, colorImg, &memReq);
    VkMemoryAllocateInfo mai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
    mai.allocationSize = memReq.size;
    mai.memoryTypeIndex = findMemoryType(phys, memReq.memoryTypeBits, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    VkDeviceMemory colorMem; vkAllocateMemory(device, &mai, nullptr, &colorMem);
    vkBindImageMemory(device, colorImg, colorMem, 0);

    // 6) Image view
    VkImageViewCreateInfo ivci{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};
    ivci.image = colorImg; ivci.viewType = VK_IMAGE_VIEW_TYPE_2D;
    ivci.format = VK_FORMAT_R8G8B8A8_UNORM;
    ivci.subresourceRange.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
    ivci.subresourceRange.levelCount = 1; ivci.subresourceRange.layerCount = 1;
    VkImageView colorView; vkCreateImageView(device, &ivci, nullptr, &colorView);

    // 7) Render pass (single color attachment)
    VkAttachmentDescription ad{};
    ad.format = VK_FORMAT_R8G8B8A8_UNORM;
    ad.samples = VK_SAMPLE_COUNT_1_BIT;
    ad.loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR;
    ad.storeOp = VK_ATTACHMENT_STORE_OP_STORE;
    ad.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    ad.finalLayout   = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
    VkAttachmentReference aref{0, VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL};
    VkSubpassDescription sub{};
    sub.pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS;
    sub.colorAttachmentCount = 1;
    sub.pColorAttachments = &aref;
    VkSubpassDependency dep{};
    dep.srcSubpass = VK_SUBPASS_EXTERNAL;
    dep.dstSubpass = 0;
    dep.srcStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
    dep.dstStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
    dep.dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
    VkRenderPassCreateInfo rpci{VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO};
    rpci.attachmentCount = 1; rpci.pAttachments = &ad;
    rpci.subpassCount = 1; rpci.pSubpasses = &sub;
    rpci.dependencyCount = 1; rpci.pDependencies = &dep;
    VkRenderPass rp; vkCreateRenderPass(device, &rpci, nullptr, &rp);

    // 8) Framebuffer
    VkFramebufferCreateInfo fci{VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO};
    fci.renderPass = rp;
    fci.attachmentCount = 1; fci.pAttachments = &colorView;
    fci.width = W; fci.height = H; fci.layers = 1;
    VkFramebuffer fb; vkCreateFramebuffer(device, &fci, nullptr, &fb);

    // 9) Pipeline (fixed-function minimal)
    // Load SPIR-V shaders
    auto vs = readFile("shaders/fullscreen.vert.spv");
    auto fs = readFile("shaders/pbr.frag.spv");
    if (vs.empty() || fs.empty()){ std::cerr<<"SPIR-V missing\n"; return 1; }
    VkShaderModuleCreateInfo smci{VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO};
    smci.codeSize = vs.size(); smci.pCode = reinterpret_cast<const uint32_t*>(vs.data());
    VkShaderModule vert; vkCreateShaderModule(device, &smci, nullptr, &vert);
    smci.codeSize = fs.size(); smci.pCode = reinterpret_cast<const uint32_t*>(fs.data());
    VkShaderModule frag; vkCreateShaderModule(device, &smci, nullptr, &frag);

    VkPipelineShaderStageCreateInfo sstages[2]{};
    sstages[0].sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
    sstages[0].stage = VK_SHADER_STAGE_VERTEX_BIT;
    sstages[0].module = vert; sstages[0].pName = "main";
    sstages[1].sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
    sstages[1].stage = VK_SHADER_STAGE_FRAGMENT_BIT;
    sstages[1].module = frag; sstages[1].pName = "main";

    VkPipelineVertexInputStateCreateInfo vi{VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO};
    VkPipelineInputAssemblyStateCreateInfo ia{VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO};
    ia.topology = VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST;

    VkViewport viewport{}; viewport.x=0; viewport.y=0; viewport.width=float(W); viewport.height=float(H); viewport.minDepth=0.0f; viewport.maxDepth=1.0f;
    VkRect2D scissor{{0,0},{W,H}};
    VkPipelineViewportStateCreateInfo vp{VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO};
    vp.viewportCount=1; vp.pViewports=&viewport; vp.scissorCount=1; vp.pScissors=&scissor;

    VkPipelineRasterizationStateCreateInfo rs{VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO};
    rs.polygonMode = VK_POLYGON_MODE_FILL; rs.cullMode = VK_CULL_MODE_NONE; rs.frontFace = VK_FRONT_FACE_COUNTER_CLOCKWISE; rs.lineWidth = 1.0f;

    VkPipelineMultisampleStateCreateInfo ms{VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO};
    ms.rasterizationSamples = VK_SAMPLE_COUNT_1_BIT;

    VkPipelineColorBlendAttachmentState cba{}; cba.colorWriteMask = 0xF;
    VkPipelineColorBlendStateCreateInfo cb{VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO};
    cb.attachmentCount = 1; cb.pAttachments = &cba;

    VkPipelineLayoutCreateInfo plci{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};
    VkPipelineLayout layout; vkCreatePipelineLayout(device, &plci, nullptr, &layout);

    VkAttachmentDescription attach = ad;
    VkPipelineRenderingCreateInfoKHR prci{}; // not used; we use renderpass pipeline below

    VkGraphicsPipelineCreateInfo gpci{VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO};
    gpci.stageCount = 2; gpci.pStages = sstages;
    gpci.pVertexInputState = &vi;
    gpci.pInputAssemblyState = &ia;
    gpci.pViewportState = &vp;
    gpci.pRasterizationState = &rs;
    gpci.pMultisampleState = &ms;
    gpci.pColorBlendState = &cb;
    gpci.layout = layout;
    gpci.renderPass = rp;
    gpci.subpass = 0;
    VkPipeline pipeline; 
    if (vkCreateGraphicsPipelines(device, VK_NULL_HANDLE, 1, &gpci, nullptr, &pipeline) != VK_SUCCESS){
        std::cerr<<"vkCreateGraphicsPipelines failed\n"; return 1;
    }

    // 10) Record commands
    VkCommandBufferBeginInfo bi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
    vkBeginCommandBuffer(cmd, &bi);

    // Transition to COLOR_ATTACHMENT_OPTIMAL
    VkImageMemoryBarrier barrier{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
    barrier.srcAccessMask = 0;
    barrier.dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
    barrier.oldLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    barrier.newLayout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
    barrier.image = colorImg;
    barrier.subresourceRange.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
    barrier.subresourceRange.levelCount = 1;
    barrier.subresourceRange.layerCount = 1;
    vkCmdPipelineBarrier(cmd,
        VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,
        VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT,
        0, 0,nullptr, 0,nullptr, 1,&barrier);

    VkClearValue clear; clear.color = { {0.02f,0.02f,0.02f,1.0f} };
    VkRenderPassBeginInfo rpbi{VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO};
    rpbi.renderPass = rp; rpbi.framebuffer = fb;
    rpbi.renderArea = {{0,0},{W,H}};
    rpbi.clearValueCount = 1; rpbi.pClearValues = &clear;
    vkCmdBeginRenderPass(cmd, &rpbi, VK_SUBPASS_CONTENTS_INLINE);
    vkCmdBindPipeline(cmd, VK_PIPELINE_BIND_POINT_GRAPHICS, pipeline);
    vkCmdDraw(cmd, 3, 1, 0, 0);
    vkCmdEndRenderPass(cmd);

    // Transition to TRANSFER_SRC_OPTIMAL
    barrier.srcAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
    barrier.dstAccessMask = VK_ACCESS_TRANSFER_READ_BIT;
    barrier.oldLayout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
    barrier.newLayout = VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL;
    vkCmdPipelineBarrier(cmd,
        VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT,
        VK_PIPELINE_STAGE_TRANSFER_BIT,
        0, 0,nullptr, 0,nullptr, 1,&barrier);

    // 11) Readback buffer
    VkDeviceSize bufSize = VkDeviceSize(W)*VkDeviceSize(H)*4;
    VkBufferCreateInfo bci{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};
    bci.size = bufSize; bci.usage = VK_BUFFER_USAGE_TRANSFER_DST_BIT;
    VkBuffer buf; vkCreateBuffer(device, &bci, nullptr, &buf);
    VkMemoryRequirements bmr; vkGetBufferMemoryRequirements(device, buf, &bmr);
    VkMemoryAllocateInfo bmai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
    bmai.allocationSize = bmr.size;
    bmai.memoryTypeIndex = findMemoryType(phys, bmr.memoryTypeBits, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
    VkDeviceMemory bmem; vkAllocateMemory(device, &bmai, nullptr, &bmem);
    vkBindBufferMemory(device, buf, bmem, 0);

    // Copy image → buffer
    VkBufferImageCopy bic{};
    bic.imageSubresource.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
    bic.imageSubresource.layerCount = 1;
    bic.imageExtent = {W,H,1};
    vkCmdCopyImageToBuffer(cmd, colorImg, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, buf, 1, &bic);

    vkEndCommandBuffer(cmd);

    // 12) Submit and wait
    VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO};
    si.commandBufferCount = 1; si.pCommandBuffers = &cmd;
    vkQueueSubmit(queue, 1, &si, VK_NULL_HANDLE);
    vkQueueWaitIdle(queue);

    // 13) Map and write PPM
    void* data = nullptr;
    vkMapMemory(device, bmem, 0, bufSize, 0, &data);
    std::vector<unsigned char> rgba(bufSize);
    std::memcpy(rgba.data(), data, size_t(bufSize));
    vkUnmapMemory(device, bmem);

    std::ofstream ppm("render_offscreen.ppm", std::ios::binary);
    ppm << "P6\n" << W << " " << H << "\n255\n";
    // write as RGB, flip Y
    for (uint32_t y=0;y<H;++y){
        uint32_t ry = H-1-y;
        for (uint32_t x=0;x<W;++x){
            size_t idx = (ry*W + x)*4;
            char rgb[3] = { (char)rgba[idx+0], (char)rgba[idx+1], (char)rgba[idx+2] };
            ppm.write(rgb, 3);
        }
    }
    ppm.close();

    // 14) Cleanup
    vkDestroyBuffer(device, buf, nullptr);
    vkFreeMemory(device, bmem, nullptr);
    vkDestroyPipeline(device, pipeline, nullptr);
    vkDestroyPipelineLayout(device, layout, nullptr);
    vkDestroyShaderModule(device, vert, nullptr);
    vkDestroyShaderModule(device, frag, nullptr);
    vkDestroyFramebuffer(device, fb, nullptr);
    vkDestroyRenderPass(device, rp, nullptr);
    vkDestroyImageView(device, colorView, nullptr);
    vkDestroyImage(device, colorImg, nullptr);
    vkFreeMemory(device, colorMem, nullptr);
    vkDestroyCommandPool(device, pool, nullptr);
    vkDestroyDevice(device, nullptr);
    vkDestroyInstance(instance, nullptr);

    std::cout << "render_offscreen: OK\n";
    return 0;
}

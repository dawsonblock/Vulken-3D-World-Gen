#include <iostream>
#include <vector>
#include "../src/vk/VulkanContext.hpp"
using namespace voxelvk;

// Transfer -> Compute -> Transfer using a single timeline semaphore with vkQueueSubmit2 if available
int main(){
    VulkanContext ctx(false);
    if (!ctx.features().timeline){
        std::cout << "timeline_chain: SKIP (no timeline)\n"; return 0;
    }
    const uint32_t N = 128;
    auto hostSrc = ctx.createBuffer(sizeof(uint32_t)*N, VK_BUFFER_USAGE_TRANSFER_SRC_BIT, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT|VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
    auto devBuf  = ctx.createBuffer(sizeof(uint32_t)*N, VK_BUFFER_USAGE_TRANSFER_DST_BIT|VK_BUFFER_USAGE_STORAGE_BUFFER_BIT|VK_BUFFER_USAGE_TRANSFER_SRC_BIT, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    auto hostDst = ctx.createBuffer(sizeof(uint32_t)*N, VK_BUFFER_USAGE_TRANSFER_DST_BIT, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT|VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
    auto* p = reinterpret_cast<uint32_t*>(hostSrc.mapped);
    for(uint32_t i=0;i<N;++i) p[i]=i;

    // Pipeline: identity copy via compute (add 0) reusing add.comp.spv by subtracting 1 later
    // We'll just use compute_sample's pipeline to add 1, then expect i+1, but copy back and subtract check.
    // Load SPIR-V
    FILE* f = fopen("shaders/add.comp.spv","rb");
    if (!f){ std::cout << "timeline_chain: SKIP (no SPIR-V)\n"; return 0; }
    fseek(f,0,SEEK_END); long sz=ftell(f); fseek(f,0,SEEK_SET);
    std::vector<uint32_t> spirv(sz/4); fread(spirv.data(),1,sz,f); fclose(f);
    VkShaderModuleCreateInfo smci{VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO};
    smci.codeSize = spirv.size()*4; smci.pCode = spirv.data();
    VkShaderModule sm; vkCreateShaderModule(ctx.device(), &smci, nullptr, &sm);

    // Descriptor layout
    VkDescriptorSetLayoutBinding b[2] = {};
    b[0].binding=0; b[0].descriptorType=VK_DESCRIPTOR_TYPE_STORAGE_BUFFER; b[0].descriptorCount=1; b[0].stageFlags=VK_SHADER_STAGE_COMPUTE_BIT;
    b[1].binding=1; b[1].descriptorType=VK_DESCRIPTOR_TYPE_STORAGE_BUFFER; b[1].descriptorCount=1; b[1].stageFlags=VK_SHADER_STAGE_COMPUTE_BIT;
    VkDescriptorSetLayoutCreateInfo lci{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO};
    lci.bindingCount=2; lci.pBindings=b;
    VkDescriptorSetLayout dsl; vkCreateDescriptorSetLayout(ctx.device(), &lci, nullptr, &dsl);
    VkPipelineLayoutCreateInfo plci{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};
    plci.setLayoutCount=1; plci.pSetLayouts=&dsl;
    VkPipelineLayout pl; vkCreatePipelineLayout(ctx.device(), &plci, nullptr, &pl);
    VkPipelineShaderStageCreateInfo ss{VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO};
    ss.stage = VK_SHADER_STAGE_COMPUTE_BIT; ss.module = sm; ss.pName="main";
    VkComputePipelineCreateInfo pci{VK_STRUCTURE_TYPE_COMPUTE_PIPELINE_CREATE_INFO};
    pci.stage = ss; pci.layout = pl;
    VkPipeline pipe; vkCreateComputePipelines(ctx.device(), VK_NULL_HANDLE, 1, &pci, nullptr, &pipe);

    // Descriptor pool + set
    VkDescriptorPoolSize ps[1] = {{VK_DESCRIPTOR_TYPE_STORAGE_BUFFER, 2}};
    VkDescriptorPoolCreateInfo dpci{VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO};
    dpci.maxSets=1; dpci.poolSizeCount=1; dpci.pPoolSizes=ps;
    VkDescriptorPool dp; vkCreateDescriptorPool(ctx.device(), &dpci, nullptr, &dp);
    VkDescriptorSetAllocateInfo dai{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO};
    dai.descriptorPool=dp; dai.descriptorSetCount=1; dai.pSetLayouts=&dsl;
    VkDescriptorSet ds; vkAllocateDescriptorSets(ctx.device(), &dai, &ds);

    VkDescriptorBufferInfo inbi{devBuf.buf,0, VK_WHOLE_SIZE};
    VkDescriptorBufferInfo outbi{devBuf.buf,0, VK_WHOLE_SIZE};
    VkWriteDescriptorSet w[2] = {};
    w[0].sType=VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET; w[0].dstSet=ds; w[0].dstBinding=0; w[0].descriptorCount=1; w[0].descriptorType=VK_DESCRIPTOR_TYPE_STORAGE_BUFFER; w[0].pBufferInfo=&inbi;
    w[1].sType=VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET; w[1].dstSet=ds; w[1].dstBinding=1; w[1].descriptorCount=1; w[1].descriptorType=VK_DESCRIPTOR_TYPE_STORAGE_BUFFER; w[1].pBufferInfo=&outbi;
    vkUpdateDescriptorSets(ctx.device(), 2, w, 0, nullptr);

    // Timeline semaphore
    VkSemaphore tls = ctx.createTimeline(0);
    if (tls==VK_NULL_HANDLE){ std::cout << "timeline_chain: SKIP (timeline not created)\n"; return 0; }

    // Submit transfer (hostSrc -> devBuf)
    auto transferRecord = [&](VkCommandBuffer cmd, void*){
        VkBufferCopy c{0,0,sizeof(uint32_t)*N};
        vkCmdCopyBuffer(cmd, hostSrc.buf, devBuf.buf, 1, &c);
    };
    // Submit compute (devBuf -> devBuf +1)
    auto computeRecord = [&](VkCommandBuffer cmd, void*){
        vkCmdBindPipeline(cmd, VK_PIPELINE_BIND_POINT_COMPUTE, pipe);
        vkCmdBindDescriptorSets(cmd, VK_PIPELINE_BIND_POINT_COMPUTE, pl, 0, 1, &ds, 0, nullptr);
        vkCmdDispatch(cmd, (N+63)/64, 1, 1);
    };
    // Submit transfer back (devBuf -> hostDst)
    auto transferBackRecord = [&](VkCommandBuffer cmd, void*){
        VkBufferCopy c{0,0,sizeof(uint32_t)*N};
        vkCmdCopyBuffer(cmd, devBuf.buf, hostDst.buf, 1, &c);
    };

    // Use QueueSubmit2 path if available; otherwise fallback to oneShot with waits
    if (ctx.features().sync2){
        // build command buffers
        auto recWrapper = [](VkCommandBuffer c, void* ud){ (*reinterpret_cast<decltype(transferRecord)*>(ud))(c,nullptr); };
        // First: transfer submit waits on nothing, signals timeline=1
        // Second: compute waits timeline=1, signals=2
        // Third: transfer waits=2, signals=3
        // Allocate buffers
        // We'll reuse oneShot with separate submits and explicit timeline waits/signal at device scope.
        ctx.oneShot(ctx.queues().transferOrGraphics(), ctx.transferQueue(), "xfer", +recWrapper, &transferRecord);
        ctx.signalTimeline(tls, 1);
        ctx.waitTimeline(tls, 1);
        ctx.oneShot(ctx.queues().graphics, ctx.graphicsQueue(), "compute", +[](VkCommandBuffer c, void* ud){ (*reinterpret_cast<decltype(computeRecord)*>(ud))(c,nullptr); }, &computeRecord);
        ctx.signalTimeline(tls, 2);
        ctx.waitTimeline(tls, 2);
        ctx.oneShot(ctx.queues().transferOrGraphics(), ctx.transferQueue(), "xferBack", +[](VkCommandBuffer c, void* ud){ (*reinterpret_cast<decltype(transferBackRecord)*>(ud))(c,nullptr); }, &transferBackRecord);
        ctx.signalTimeline(tls, 3);
    } else {
        // Fallback: sequential
        ctx.oneShot(ctx.queues().transferOrGraphics(), ctx.transferQueue(), "xfer", +[](VkCommandBuffer c, void* ud){ (*reinterpret_cast<decltype(transferRecord)*>(ud))(c,nullptr); }, &transferRecord);
        ctx.oneShot(ctx.queues().graphics, ctx.graphicsQueue(), "compute", +[](VkCommandBuffer c, void* ud){ (*reinterpret_cast<decltype(computeRecord)*>(ud))(c,nullptr); }, &computeRecord);
        ctx.oneShot(ctx.queues().transferOrGraphics(), ctx.transferQueue(), "xferBack", +[](VkCommandBuffer c, void* ud){ (*reinterpret_cast<decltype(transferBackRecord)*>(ud))(c,nullptr); }, &transferBackRecord);
    }

    // Validate
    auto* q = reinterpret_cast<uint32_t*>(hostDst.mapped);
    bool ok = true; for(uint32_t i=0;i<N;++i) if (q[i] != i+1) { ok=false; break; }

    vkDestroySemaphore(ctx.device(), tls, nullptr);
    vkDestroyDescriptorPool(ctx.device(), dp, nullptr);
    vkDestroyPipeline(ctx.device(), pipe, nullptr);
    vkDestroyShaderModule(ctx.device(), sm, nullptr);
    vkDestroyPipelineLayout(ctx.device(), pl, nullptr);
    vkDestroyDescriptorSetLayout(ctx.device(), dsl, nullptr);
    ctx.destroyBuffer(hostSrc); ctx.destroyBuffer(devBuf); ctx.destroyBuffer(hostDst);

    if (!ok){ std::cerr << "timeline_chain: FAIL\n"; return 1; }
    std::cout << "timeline_chain: OK\n";
    return 0;
}

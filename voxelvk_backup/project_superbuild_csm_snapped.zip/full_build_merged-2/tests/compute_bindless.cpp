
#include "vk/VulkanContext.hpp"
#include <iostream>
#include <vector>
#include <cstring>

using namespace voxelvk;

int main(){
    try{
        VulkanContext ctx(std::getenv("VOXELVK_VALIDATION")!=nullptr);
        if (!ctx.hasDescriptorIndexing()){
            std::cout << "compute_bindless: SKIPPED (no descriptor indexing)\n";
            return 0;
        }

        const uint32_t N = 512;
        const uint32_t M = 4; // number of buffers in bindless array

        std::vector<Buffer> devBufs;
        std::vector<VkDescriptorBufferInfo> infos;
        devBufs.reserve(M); infos.reserve(M);
        for (uint32_t i=0;i<M;++i){
            auto b = ctx.createBuffer(N*sizeof(uint32_t),
                VK_BUFFER_USAGE_STORAGE_BUFFER_BIT|VK_BUFFER_USAGE_TRANSFER_SRC_BIT|VK_BUFFER_USAGE_TRANSFER_DST_BIT,
                VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
            devBufs.push_back(b);
            infos.push_back({ b.buffer, 0, VK_WHOLE_SIZE });
        }

        // host out for validation
        auto hostOut = ctx.createBuffer(N*sizeof(uint32_t),
            VK_BUFFER_USAGE_TRANSFER_DST_BIT, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT|VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);

        // Load shader
        FILE* f = fopen("shaders/multi_write.comp.spv", "rb");
        if (!f) f = fopen("../shaders/multi_write.comp.spv", "rb");
        if (!f) throw std::runtime_error("cannot open multi_write.comp.spv");
        fseek(f, 0, SEEK_END); long len = ftell(f); fseek(f, 0, SEEK_SET);
        std::vector<uint32_t> spv(len/4); fread(spv.data(),1,len,f); fclose(f);
        VkShaderModuleCreateInfo smi{ VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO };
        smi.codeSize = spv.size()*4; smi.pCode = spv.data();
        VkShaderModule sm; if (vkCreateShaderModule(ctx.device(), &smi, nullptr, &sm)!=VK_SUCCESS) throw std::runtime_error("shader module");

        // descriptor set layout with variable descriptor count
        VkDescriptorSetLayoutBinding bind{};
        bind.binding = 0; bind.descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
        bind.descriptorCount = M; bind.stageFlags = VK_SHADER_STAGE_COMPUTE_BIT;

        VkDescriptorBindingFlags flags =
            VK_DESCRIPTOR_BINDING_PARTIALLY_BOUND_BIT |
            VK_DESCRIPTOR_BINDING_VARIABLE_DESCRIPTOR_COUNT_BIT |
            VK_DESCRIPTOR_BINDING_UPDATE_AFTER_BIND_BIT;

        VkDescriptorSetLayoutBindingFlagsCreateInfo bf{ VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_BINDING_FLAGS_CREATE_INFO };
        bf.bindingCount = 1; bf.pBindingFlags = &flags;

        VkDescriptorSetLayoutCreateInfo lci{ VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO };
        lci.pNext = &bf;
        lci.bindingCount = 1; lci.pBindings = &bind;
        lci.flags = VK_DESCRIPTOR_SET_LAYOUT_CREATE_UPDATE_AFTER_BIND_POOL_BIT;
        VkDescriptorSetLayout setLayout; vkCreateDescriptorSetLayout(ctx.device(), &lci, nullptr, &setLayout);

        VkPipelineLayoutCreateInfo plci{ VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO };
        plci.setLayoutCount = 1; plci.pSetLayouts = &setLayout;
        VkPushConstantRange pcr{ VK_SHADER_STAGE_COMPUTE_BIT, 0, 4 };
        plci.pushConstantRangeCount = 1; plci.pPushConstantRanges = &pcr;
        VkPipelineLayout pipeLayout; vkCreatePipelineLayout(ctx.device(), &plci, nullptr, &pipeLayout);

        VkPipelineShaderStageCreateInfo stage{ VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO };
        stage.stage = VK_SHADER_STAGE_COMPUTE_BIT; stage.module = sm; stage.pName = "main";
        VkComputePipelineCreateInfo pci{ VK_STRUCTURE_TYPE_COMPUTE_PIPELINE_CREATE_INFO };
        pci.stage = stage; pci.layout = pipeLayout;
        VkPipeline pipe; if (vkCreateComputePipelines(ctx.device(), VK_NULL_HANDLE, 1, &pci, nullptr, &pipe)!=VK_SUCCESS) throw std::runtime_error("create pipeline");

        // variable descriptor count allocation
        uint32_t counts[1] = { M };
        VkDescriptorSetVariableDescriptorCountAllocateInfo vinfo{ VK_STRUCTURE_TYPE_DESCRIPTOR_SET_VARIABLE_DESCRIPTOR_COUNT_ALLOCATE_INFO };
        vinfo.descriptorSetCount = 1; vinfo.pDescriptorCounts = counts;

        VkDescriptorSetAllocateInfo sai{ VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO };
        sai.descriptorPool = ctx.descriptorPool();
        sai.descriptorSetCount = 1; sai.pSetLayouts = &setLayout; sai.pNext = &vinfo;
        VkDescriptorSet set; vkAllocateDescriptorSets(ctx.device(), &sai, &set);

        // write all M storage buffers
        std::vector<VkWriteDescriptorSet> writes(1);
        writes[0].sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
        writes[0].dstSet = set; writes[0].dstBinding = 0;
        writes[0].descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
        writes[0].descriptorCount = M;
        writes[0].pBufferInfo = infos.data();
        vkUpdateDescriptorSets(ctx.device(), (uint32_t)writes.size(), writes.data(), 0, nullptr);

        // dispatch
        ctx.submitOneShot(ctx.graphicsQueue(), ctx.queues().graphics, [&](VkCommandBuffer cmd){
            vkCmdBindPipeline(cmd, VK_PIPELINE_BIND_POINT_COMPUTE, pipe);
            vkCmdBindDescriptorSets(cmd, VK_PIPELINE_BIND_POINT_COMPUTE, pipeLayout, 0, 1, &set, 0, nullptr);
            uint32_t Nbuf = M;
            vkCmdPushConstants(cmd, pipeLayout, VK_SHADER_STAGE_COMPUTE_BIT, 0, 4, &Nbuf);
            vkCmdDispatch(cmd, (N+63)/64, 1, 1);
        });

        // Copy one buffer back and validate pattern
        ctx.copyBuffer(devBufs[0].buffer, hostOut.buffer, hostOut.size, ctx.transferQueue(), ctx.queues().transfer);
        void* p; vkMapMemory(ctx.device(), hostOut.memory, 0, VK_WHOLE_SIZE, 0, &p);
        auto* u = reinterpret_cast<uint32_t*>(p);
        for (uint32_t i=0;i<N;++i){
            if (u[i] != i + 0){
                std::cerr << "bindless mismatch at " << i << " got " << u[i] << std::endl;
                return 1;
            }
        }
        vkUnmapMemory(ctx.device(), hostOut.memory);

        for (auto &b : devBufs) ctx.destroyBuffer(b);
        ctx.destroyBuffer(hostOut);
        vkDestroyPipeline(ctx.device(), pipe, nullptr);
        vkDestroyPipelineLayout(ctx.device(), pipeLayout, nullptr);
        vkDestroyDescriptorSetLayout(ctx.device(), setLayout, nullptr);
        vkDestroyShaderModule(ctx.device(), sm, nullptr);

        std::cout << "compute_bindless: OK\n";
        return 0;
    }catch(const std::exception& e){
        std::cerr << "compute_bindless error: " << e.what() << std::endl;
        return 1;
    }
}

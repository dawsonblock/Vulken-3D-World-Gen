
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "../third_party/stb_image_write.h"
#include <vulkan/vulkan.h>
#include <vector>
#include <iostream>
#include <cstring>
#include <cassert>

static uint32_t findMemoryType(VkPhysicalDevice phys, uint32_t typeFilter, VkMemoryPropertyFlags props){
    VkPhysicalDeviceMemoryProperties memProps;
    vkGetPhysicalDeviceMemoryProperties(phys, &memProps);
    for(uint32_t i=0;i<memProps.memoryTypeCount;++i){
        if ((typeFilter & (1u<<i)) && (memProps.memoryTypes[i].propertyFlags & props) == props)
            return i;
    }
    return ~0u;
}

static bool hasExt(VkPhysicalDevice dev, const char* name){
    uint32_t count=0; vkEnumerateDeviceExtensionProperties(dev,nullptr,&count,nullptr);
    std::vector<VkExtensionProperties> exts(count); vkEnumerateDeviceExtensionProperties(dev,nullptr,&count,exts.data());
    for(auto& e: exts) if (std::strcmp(e.extensionName,name)==0) return true;
    return false;
}

int main(){
    const uint32_t W=512, H=256;
    // Instance
    VkApplicationInfo app{VK_STRUCTURE_TYPE_APPLICATION_INFO};
    app.pApplicationName="render_dynamic";
    app.apiVersion = VK_API_VERSION_1_3;
    VkInstanceCreateInfo ici{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};
    ici.pApplicationInfo = &app;
    VkInstance instance = VK_NULL_HANDLE;
    if (vkCreateInstance(&ici,nullptr,&instance)!=VK_SUCCESS){ std::cerr<<"vkCreateInstance failed\n"; return 1; }

    // Physical device
    uint32_t ndev=0; vkEnumeratePhysicalDevices(instance,&ndev,nullptr);
    if(!ndev){ std::cerr<<"no device\n"; return 1; }
    std::vector<VkPhysicalDevice> devs(ndev); vkEnumeratePhysicalDevices(instance,&ndev,devs.data());
    VkPhysicalDevice phys = devs[0];

    // Queues
    uint32_t qCount=0; vkGetPhysicalDeviceQueueFamilyProperties(phys,&qCount,nullptr);
    std::vector<VkQueueFamilyProperties> qprops(qCount); vkGetPhysicalDeviceQueueFamilyProperties(phys,&qCount,qprops.data());
    uint32_t gfxIndex = VK_QUEUE_FAMILY_IGNORED;
    for(uint32_t i=0;i<qCount;++i) if (qprops[i].queueFlags & VK_QUEUE_GRAPHICS_BIT){ gfxIndex=i; break; }
    if (gfxIndex==VK_QUEUE_FAMILY_IGNORED){ std::cerr<<"no graphics queue\n"; return 1; }

    // Feature gating: dynamic rendering + sync2
    bool wantDyn = true, wantSync2 = true;
    bool enableDynExt = hasExt(phys, "VK_KHR_dynamic_rendering");
    bool enableSync2Ext = hasExt(phys, "VK_KHR_synchronization2");

    VkPhysicalDeviceDynamicRenderingFeatures dynFeat{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_DYNAMIC_RENDERING_FEATURES};
    dynFeat.dynamicRendering = VK_TRUE;
    VkPhysicalDeviceSynchronization2Features sync2{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_SYNCHRONIZATION_2_FEATURES};
    sync2.synchronization2 = VK_TRUE;

    void* pNext = nullptr;
    if (wantDyn && enableDynExt) { dynFeat.pNext = pNext; pNext = &dynFeat; }
    if (wantSync2 && enableSync2Ext) { sync2.pNext = pNext; pNext = &sync2; }

    float prio=1.f;
    VkDeviceQueueCreateInfo qci{VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO};
    qci.queueFamilyIndex = gfxIndex;
    qci.queueCount = 1;
    qci.pQueuePriorities = &prio;

    std::vector<const char*> devExts;
    if (enableDynExt) devExts.push_back("VK_KHR_dynamic_rendering");
    if (enableSync2Ext) devExts.push_back("VK_KHR_synchronization2");

    VkDeviceCreateInfo dci{VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO};
    dci.pNext = pNext;
    dci.queueCreateInfoCount = 1;
    dci.pQueueCreateInfos = &qci;
    dci.enabledExtensionCount = (uint32_t)devExts.size();
    dci.ppEnabledExtensionNames = devExts.empty()? nullptr : devExts.data();

    VkDevice device=VK_NULL_HANDLE;
    if (vkCreateDevice(phys,&dci,nullptr,&device)!=VK_SUCCESS){ std::cerr<<"vkCreateDevice failed\n"; return 1; }
    VkQueue gfxQ=VK_NULL_HANDLE; vkGetDeviceQueue(device,gfxIndex,0,&gfxQ);

    // Create offscreen image + view
    VkFormat format = VK_FORMAT_R8G8B8A8_UNORM;
    VkImageCreateInfo ici2{VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};
    ici2.imageType = VK_IMAGE_TYPE_2D;
    ici2.format = format;
    ici2.extent = {W,H,1};
    ici2.mipLevels = 1;
    ici2.arrayLayers = 1;
    ici2.samples = VK_SAMPLE_COUNT_1_BIT;
    ici2.tiling = VK_IMAGE_TILING_OPTIMAL;
    ici2.usage = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT | VK_IMAGE_USAGE_TRANSFER_SRC_BIT;
    VkImage img; vkCreateImage(device,&ici2,nullptr,&img);
    VkMemoryRequirements memreq; vkGetImageMemoryRequirements(device,img,&memreq);
    uint32_t memIndex = findMemoryType(phys, memreq.memoryTypeBits, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    VkMemoryAllocateInfo mai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
    mai.allocationSize = memreq.size; mai.memoryTypeIndex = memIndex;
    VkDeviceMemory imgMem; vkAllocateMemory(device,&mai,nullptr,&imgMem);
    vkBindImageMemory(device,img,imgMem,0);

    VkImageViewCreateInfo ivci{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};
    ivci.image = img; ivci.viewType = VK_IMAGE_VIEW_TYPE_2D; ivci.format = format;
    ivci.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT,0,1,0,1};
    VkImageView view; vkCreateImageView(device,&ivci,nullptr,&view);

    // Create shader modules (SPIR-V expected beside binary)
    auto loadFile=[&](const char* path)->std::vector<uint32_t>{
        FILE* f = fopen(path,"rb"); if(!f) return {};
        fseek(f,0,SEEK_END); long sz=ftell(f); fseek(f,0,SEEK_SET);
        std::vector<uint32_t> data((size_t)sz/4);
        fread(data.data(),1,sz,f); fclose(f); return data;
    };
    auto vert = loadFile("fullscreen.vert.spv");
    auto frag = loadFile("pbr.frag.spv");
    if (vert.empty()||frag.empty()){ std::cerr<<"missing SPV\n"; return 1; }
    VkShaderModuleCreateInfo smci{VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO};
    smci.codeSize = vert.size()*4; smci.pCode = vert.data();
    VkShaderModule vs; vkCreateShaderModule(device,&smci,nullptr,&vs);
    smci.codeSize = frag.size()*4; smci.pCode = frag.data();
    VkShaderModule fs; vkCreateShaderModule(device,&smci,nullptr,&fs);

    // Pipeline layout
    VkPipelineLayoutCreateInfo plci{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};
    VkPipelineLayout pl; vkCreatePipelineLayout(device,&plci,nullptr,&pl);

    // Dynamic rendering pipeline
    VkPipelineRenderingCreateInfo prci{VK_STRUCTURE_TYPE_PIPELINE_RENDERING_CREATE_INFO};
    prci.colorAttachmentCount = 1;
    prci.pColorAttachmentFormats = &format;

    VkPipelineShaderStageCreateInfo stages[2] = {};
    stages[0].sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
    stages[0].stage = VK_SHADER_STAGE_VERTEX_BIT;
    stages[0].module = vs; stages[0].pName = "main";
    stages[1].sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
    stages[1].stage = VK_SHADER_STAGE_FRAGMENT_BIT;
    stages[1].module = fs; stages[1].pName = "main";

    VkPipelineVertexInputStateCreateInfo vi{VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO};
    VkPipelineInputAssemblyStateCreateInfo ia{VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO};
    ia.topology = VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST;
    VkPipelineViewportStateCreateInfo vp{VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO};
    vp.viewportCount=1; vp.scissorCount=1;
    VkPipelineRasterizationStateCreateInfo rs{VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO};
    rs.polygonMode = VK_POLYGON_MODE_FILL; rs.cullMode = VK_CULL_MODE_NONE; rs.lineWidth = 1.0f;
    VkPipelineMultisampleStateCreateInfo ms{VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO};
    ms.rasterizationSamples = VK_SAMPLE_COUNT_1_BIT;
    VkPipelineColorBlendAttachmentState cba{}; cba.colorWriteMask = 0xF;
    VkPipelineColorBlendStateCreateInfo cb{VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO};
    cb.attachmentCount = 1; cb.pAttachments = &cba;
    VkDynamicState dynStates[2] = { VK_DYNAMIC_STATE_VIEWPORT, VK_DYNAMIC_STATE_SCISSOR };
    VkPipelineDynamicStateCreateInfo dyn{VK_STRUCTURE_TYPE_PIPELINE_DYNAMIC_STATE_CREATE_INFO};
    dyn.dynamicStateCount = 2; dyn.pDynamicStates = dynStates;

    VkGraphicsPipelineCreateInfo gpci{VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO};
    gpci.pNext = &prci;
    gpci.stageCount = 2; gpci.pStages = stages;
    gpci.pVertexInputState = &vi;
    gpci.pInputAssemblyState = &ia;
    gpci.pViewportState = &vp;
    gpci.pRasterizationState = &rs;
    gpci.pMultisampleState = &ms;
    gpci.pColorBlendState = &cb;
    gpci.pDynamicState = &dyn;
    gpci.layout = pl;

    VkPipeline pipe; 
    if (vkCreateGraphicsPipelines(device,VK_NULL_HANDLE,1,&gpci,nullptr,&pipe)!=VK_SUCCESS){
        std::cerr<<"vkCreateGraphicsPipelines failed\n"; return 1;
    }

    // Command pool/buffer
    VkCommandPoolCreateInfo cpci{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
    cpci.queueFamilyIndex = gfxIndex;
    VkCommandPool pool; vkCreateCommandPool(device,&cpci,nullptr,&pool);
    VkCommandBufferAllocateInfo cbai{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
    cbai.commandPool = pool; cbai.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY; cbai.commandBufferCount = 1;
    VkCommandBuffer cmd; vkAllocateCommandBuffers(device,&cbai,&cmd);

    // Buffer for readback
    VkDeviceSize bufSize = W*H*4;
    VkBufferCreateInfo bci{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};
    bci.size = bufSize; bci.usage = VK_BUFFER_USAGE_TRANSFER_DST_BIT;
    VkBuffer buf; vkCreateBuffer(device,&bci,nullptr,&buf);
    VkMemoryRequirements bmr; vkGetBufferMemoryRequirements(device,buf,&bmr);
    uint32_t hostIndex = findMemoryType(phys, bmr.memoryTypeBits, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT|VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
    VkMemoryAllocateInfo mai2{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO}; mai2.allocationSize=bmr.size; mai2.memoryTypeIndex=hostIndex;
    VkDeviceMemory bufMem; vkAllocateMemory(device,&mai2,nullptr,&bufMem);
    vkBindBufferMemory(device,buf,bufMem,0);

    // Record
    VkCommandBufferBeginInfo bi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
    vkBeginCommandBuffer(cmd,&bi);

    // Layout transition to COLOR_ATTACHMENT_OPTIMAL
    VkImageMemoryBarrier2 barrier1{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER_2};
    barrier1.srcStageMask = VK_PIPELINE_STAGE_2_TOP_OF_PIPE_BIT;
    barrier1.dstStageMask = VK_PIPELINE_STAGE_2_COLOR_ATTACHMENT_OUTPUT_BIT;
    barrier1.srcAccessMask = 0;
    barrier1.dstAccessMask = VK_ACCESS_2_COLOR_ATTACHMENT_WRITE_BIT;
    barrier1.oldLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    barrier1.newLayout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
    barrier1.image = img;
    barrier1.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT,0,1,0,1};
    VkDependencyInfo dep1{VK_STRUCTURE_TYPE_DEPENDENCY_INFO};
    dep1.imageMemoryBarrierCount = 1; dep1.pImageMemoryBarriers = &barrier1;

    // If sync2 not enabled, fallback to legacy barrier
    if (enableSync2Ext){
        vkCmdPipelineBarrier2(cmd,&dep1);
    } else {
        VkImageMemoryBarrier b{};
        b.sType=VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER;
        b.srcAccessMask=0; b.dstAccessMask=VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
        b.oldLayout=VK_IMAGE_LAYOUT_UNDEFINED; b.newLayout=VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
        b.srcQueueFamilyIndex=VK_QUEUE_FAMILY_IGNORED; b.dstQueueFamilyIndex=VK_QUEUE_FAMILY_IGNORED;
        b.image=img; b.subresourceRange=barrier1.subresourceRange;
        vkCmdPipelineBarrier(cmd, VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT, VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT, 0,
                             0,nullptr, 0,nullptr, 1,&b);
    }

    // Begin dynamic rendering
    VkRenderingAttachmentInfo colorAtt{VK_STRUCTURE_TYPE_RENDERING_ATTACHMENT_INFO};
    colorAtt.imageView = view;
    colorAtt.imageLayout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
    colorAtt.loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR;
    colorAtt.storeOp = VK_ATTACHMENT_STORE_OP_STORE;
    VkClearValue clear; clear.color = { {0.0f,0.0f,0.0f,1.0f} };
    colorAtt.clearValue = clear;

    VkRenderingInfo ri{VK_STRUCTURE_TYPE_RENDERING_INFO};
    ri.renderArea = { {0,0}, {W,H} };
    ri.layerCount = 1;
    ri.colorAttachmentCount = 1;
    ri.pColorAttachments = &colorAtt;

    vkCmdBeginRendering(cmd,&ri);
    VkViewport vpv{0,0,(float)W,(float)H,0.0f,1.0f};
    VkRect2D sc{ {0,0}, {W,H} };
    vkCmdSetViewport(cmd,0,1,&vpv);
    vkCmdSetScissor(cmd,0,1,&sc);
    vkCmdBindPipeline(cmd, VK_PIPELINE_BIND_POINT_GRAPHICS, pipe);
    vkCmdDraw(cmd,3,1,0,0);
    vkCmdEndRendering(cmd);

    // Transition for copy
    VkImageMemoryBarrier2 barrier2{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER_2};
    barrier2.srcStageMask = VK_PIPELINE_STAGE_2_COLOR_ATTACHMENT_OUTPUT_BIT;
    barrier2.dstStageMask = VK_PIPELINE_STAGE_2_TRANSFER_BIT;
    barrier2.srcAccessMask = VK_ACCESS_2_COLOR_ATTACHMENT_WRITE_BIT;
    barrier2.dstAccessMask = VK_ACCESS_2_TRANSFER_READ_BIT;
    barrier2.oldLayout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
    barrier2.newLayout = VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL;
    barrier2.image = img;
    barrier2.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT,0,1,0,1};
    VkDependencyInfo dep2{VK_STRUCTURE_TYPE_DEPENDENCY_INFO};
    dep2.imageMemoryBarrierCount = 1; dep2.pImageMemoryBarriers = &barrier2;
    if (enableSync2Ext){
        vkCmdPipelineBarrier2(cmd,&dep2);
    } else {
        VkImageMemoryBarrier b{};
        b.sType=VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER;
        b.srcAccessMask=VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT; b.dstAccessMask=VK_ACCESS_TRANSFER_READ_BIT;
        b.oldLayout=VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL; b.newLayout=VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL;
        b.srcQueueFamilyIndex=VK_QUEUE_FAMILY_IGNORED; b.dstQueueFamilyIndex=VK_QUEUE_FAMILY_IGNORED;
        b.image=img; b.subresourceRange=barrier2.subresourceRange;
        vkCmdPipelineBarrier(cmd, VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT, 0,
                             0,nullptr, 0,nullptr, 1,&b);
    }

    // Copy image to buffer
    VkBufferImageCopy reg{};
    reg.bufferOffset = 0;
    reg.bufferRowLength = 0; // tightly packed
    reg.bufferImageHeight = 0;
    reg.imageSubresource = {VK_IMAGE_ASPECT_COLOR_BIT,0,0,1};
    reg.imageOffset = {0,0,0};
    reg.imageExtent = {W,H,1};
    vkCmdCopyImageToBuffer(cmd, img, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, buf, 1, &reg);

    vkEndCommandBuffer(cmd);

    // Submit & wait
    VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO};
    si.commandBufferCount = 1; si.pCommandBuffers = &cmd;
    vkQueueSubmit(gfxQ,1,&si,VK_NULL_HANDLE);
    vkQueueWaitIdle(gfxQ);

    // Readback & write PNG (PPM fallback inside stb shim)
    void* mapped=nullptr; vkMapMemory(device,bufMem,0,bufSize,0,&mapped);
    // stbi_write_png will write a P6 PPM via shim; name it .ppm
    const char* outName = "render_dynamic.ppm";
    int ok = stbi_write_png(outName, (int)W, (int)H, 4, mapped, (int)(W*4));
    vkUnmapMemory(device,bufMem);
    if(!ok){ std::cerr<<"image write failed\n"; return 1; }

    // Cleanup
    vkDestroyBuffer(device,buf,nullptr);
    vkFreeMemory(device,bufMem,nullptr);
    vkDestroyPipeline(device,pipe,nullptr);
    vkDestroyPipelineLayout(device,pl,nullptr);
    vkDestroyShaderModule(device,vs,nullptr);
    vkDestroyShaderModule(device,fs,nullptr);
    vkDestroyImageView(device,view,nullptr);
    vkDestroyImage(device,img,nullptr);
    vkFreeMemory(device,imgMem,nullptr);
    vkDestroyCommandPool(device,pool,nullptr);
    vkDestroyDevice(device,nullptr);
    vkDestroyInstance(instance,nullptr);

    std::cout<<"render_dynamic: OK\n";
    return 0;
}

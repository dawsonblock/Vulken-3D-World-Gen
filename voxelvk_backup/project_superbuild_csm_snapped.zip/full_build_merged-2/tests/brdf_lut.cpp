#include <iostream>
#include <vector>
#include <cstdio>
#include "../src/vk/VulkanContext.hpp"
using namespace voxelvk;

struct LutParams { int W=128; int H=128; };

static void savePPM(const char* path, int W, int H, const std::vector<unsigned char>& rgb){
    FILE* f = fopen(path,"wb"); if(!f) return;
    fprintf(f,"P6\n%d %d\n255\n", W, H);
    fwrite(rgb.data(),1,rgb.size(),f);
    fclose(f);
}

int main(){
    VulkanContext ctx(false);
    // Create output image (RGBA8) and staging buffer
    LutParams P;
    VkImageCreateInfo ici{VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};
    ici.imageType=VK_IMAGE_TYPE_2D; ici.extent={ (uint32_t)P.W,(uint32_t)P.H,1 }; ici.mipLevels=1; ici.arrayLayers=1;
    ici.format=VK_FORMAT_R8G8B8A8_UNORM; ici.tiling=VK_IMAGE_TILING_OPTIMAL;
    ici.usage=VK_IMAGE_USAGE_STORAGE_BIT|VK_IMAGE_USAGE_TRANSFER_SRC_BIT; ici.samples=VK_SAMPLE_COUNT_1_BIT;
    VkImage img; vkCreateImage(ctx.device(), &ici, nullptr, &img);
    VkMemoryRequirements mr; vkGetImageMemoryRequirements(ctx.device(), img, &mr);
    VkMemoryAllocateInfo ai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
    ai.allocationSize = mr.size; ai.memoryTypeIndex = ctx.findMemoryType(mr.memoryTypeBits, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    VkDeviceMemory mem; vkAllocateMemory(ctx.device(), &ai, nullptr, &mem); vkBindImageMemory(ctx.device(), img, mem, 0);

    VkImageViewCreateInfo vci{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};
    vci.image=img; vci.viewType=VK_IMAGE_VIEW_TYPE_2D; vci.format=ici.format;
    vci.subresourceRange.aspectMask=VK_IMAGE_ASPECT_COLOR_BIT; vci.subresourceRange.levelCount=1; vci.subresourceRange.layerCount=1;
    VkImageView view; vkCreateImageView(ctx.device(), &vci, nullptr, &view);

    auto staging = ctx.createBuffer(P.W*P.H*4, VK_BUFFER_USAGE_TRANSFER_DST_BIT, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT|VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);

    // Descriptor set layout
    VkDescriptorSetLayoutBinding b{}; b.binding=0; b.descriptorType=VK_DESCRIPTOR_TYPE_STORAGE_IMAGE; b.descriptorCount=1; b.stageFlags=VK_SHADER_STAGE_COMPUTE_BIT;
    VkDescriptorSetLayoutCreateInfo lci{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO};
    lci.bindingCount=1; lci.pBindings=&b;
    VkDescriptorSetLayout dsl; vkCreateDescriptorSetLayout(ctx.device(), &lci, nullptr, &dsl);
    VkPipelineLayoutCreateInfo plci{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};
    plci.setLayoutCount=1; plci.pSetLayouts=&dsl;
    VkPipelineLayout pl; vkCreatePipelineLayout(ctx.device(), &plci, nullptr, &pl);

    // Shader
    FILE* f = fopen("shaders/brdf_lut.comp.spv","rb");
    if (!f){ std::cout << "brdf_lut: SKIP (no shader)\n"; return 0; }
    fseek(f,0,SEEK_END); long sz=ftell(f); fseek(f,0,SEEK_SET);
    std::vector<uint32_t> code(sz/4); fread(code.data(),1,sz,f); fclose(f);
    VkShaderModuleCreateInfo smci{VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO}; smci.codeSize=code.size()*4; smci.pCode=code.data();
    VkShaderModule sm; vkCreateShaderModule(ctx.device(), &smci, nullptr, &sm);
    VkPipelineShaderStageCreateInfo ss{VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO};
    ss.stage=VK_SHADER_STAGE_COMPUTE_BIT; ss.module=sm; ss.pName="main";
    VkComputePipelineCreateInfo pci{VK_STRUCTURE_TYPE_COMPUTE_PIPELINE_CREATE_INFO};
    pci.stage=ss; pci.layout=pl;
    VkPipeline pipe; vkCreateComputePipelines(ctx.device(), VK_NULL_HANDLE, 1, &pci, nullptr, &pipe);

    // Descriptor pool + set
    VkDescriptorPoolSize ps{VK_DESCRIPTOR_TYPE_STORAGE_IMAGE, 1};
    VkDescriptorPoolCreateInfo dpci{VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO};
    dpci.maxSets=1; dpci.poolSizeCount=1; dpci.pPoolSizes=&ps;
    VkDescriptorPool dp; vkCreateDescriptorPool(ctx.device(), &dpci, nullptr, &dp);
    VkDescriptorSetAllocateInfo dai{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO};
    dai.descriptorPool=dp; dai.descriptorSetCount=1; dai.pSetLayouts=&dsl;
    VkDescriptorSet ds; vkAllocateDescriptorSets(ctx.device(), &dai, &ds);

    VkDescriptorImageInfo iii{}; iii.imageView=view; iii.imageLayout=VK_IMAGE_LAYOUT_GENERAL;
    VkWriteDescriptorSet w{VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET};
    w.dstSet=ds; w.dstBinding=0; w.descriptorCount=1; w.descriptorType=VK_DESCRIPTOR_TYPE_STORAGE_IMAGE; w.pImageInfo=&iii;
    vkUpdateDescriptorSets(ctx.device(), 1, &w, 0, nullptr);

    // Record compute and copy to buffer
    auto record = [&](VkCommandBuffer cmd, void*){
        // transition to GENERAL
        VkImageMemoryBarrier barrier1{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
        barrier1.srcAccessMask = 0; barrier1.dstAccessMask = VK_ACCESS_SHADER_WRITE_BIT;
        barrier1.oldLayout = VK_IMAGE_LAYOUT_UNDEFINED; barrier1.newLayout = VK_IMAGE_LAYOUT_GENERAL;
        barrier1.image = img; barrier1.subresourceRange.aspectMask=VK_IMAGE_ASPECT_COLOR_BIT; barrier1.subresourceRange.levelCount=1; barrier1.subresourceRange.layerCount=1;
        vkCmdPipelineBarrier(cmd, VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT, 0, 0,nullptr, 0,nullptr, 1, &barrier1);

        vkCmdBindPipeline(cmd, VK_PIPELINE_BIND_POINT_COMPUTE, pipe);
        vkCmdBindDescriptorSets(cmd, VK_PIPELINE_BIND_POINT_COMPUTE, pl, 0, 1, &ds, 0, nullptr);
        vkCmdDispatch(cmd, (P.W+7)/8, (P.H+7)/8, 1);

        // transition for transfer
        VkImageMemoryBarrier barrier2{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
        barrier2.srcAccessMask = VK_ACCESS_SHADER_WRITE_BIT; barrier2.dstAccessMask = VK_ACCESS_TRANSFER_READ_BIT;
        barrier2.oldLayout = VK_IMAGE_LAYOUT_GENERAL; barrier2.newLayout = VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL;
        barrier2.image = img; barrier2.subresourceRange.aspectMask=VK_IMAGE_ASPECT_COLOR_BIT; barrier2.subresourceRange.levelCount=1; barrier2.subresourceRange.layerCount=1;
        vkCmdPipelineBarrier(cmd, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT, 0, 0,nullptr, 0,nullptr, 1, &barrier2);

        VkBufferImageCopy bic{}; bic.bufferOffset=0; bic.imageSubresource.aspectMask=VK_IMAGE_ASPECT_COLOR_BIT; bic.imageSubresource.layerCount=1;
        bic.imageExtent = { (uint32_t)P.W,(uint32_t)P.H,1 };
        vkCmdCopyImageToBuffer(cmd, img, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, staging.buf, 1, &bic);
    };
    ctx.oneShot(ctx.queues().graphics, ctx.graphicsQueue(), "brdf", +[](VkCommandBuffer c, void* ud){ (*reinterpret_cast<decltype(record)*>(ud))(c,nullptr); }, &record);

    // Save
    std::vector<unsigned char> rgb(P.W*P.H*3);
    unsigned char* src = reinterpret_cast<unsigned char*>(staging.mapped);
    for (int i=0;i<P.W*P.H;i++){
        rgb[i*3+0]=src[i*4+0];
        rgb[i*3+1]=src[i*4+1];
        rgb[i*3+2]=src[i*4+2];
    }
    savePPM("brdf_lut.ppm", P.W, P.H, rgb);

    // Cleanup
    vkDestroyDescriptorPool(ctx.device(), dp, nullptr);
    vkDestroyPipeline(ctx.device(), pipe, nullptr);
    vkDestroyShaderModule(ctx.device(), sm, nullptr);
    vkDestroyPipelineLayout(ctx.device(), pl, nullptr);
    vkDestroyDescriptorSetLayout(ctx.device(), dsl, nullptr);
    vkDestroyImageView(ctx.device(), view, nullptr);
    vkDestroyImage(ctx.device(), img, nullptr);
    vkFreeMemory(ctx.device(), mem, nullptr);
    ctx.destroyBuffer(staging);

    std::cout << "brdf_lut: OK\n";
    return 0;
}

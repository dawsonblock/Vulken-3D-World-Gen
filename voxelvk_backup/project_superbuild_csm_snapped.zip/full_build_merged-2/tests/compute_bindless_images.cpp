#include <iostream>
#include <vector>
#include <cstring>
#include "../src/vk/VulkanContext.hpp"
using namespace voxelvk;

int main(){
    VulkanContext ctx(false);
    if (!(ctx.features().descriptorIndexing && ctx.features().runtimeDescriptorArray && ctx.features().variableDescriptorCount)){
        std::cout << "compute_bindless_images: SKIP (no descriptor indexing)\n"; return 0;
    }
    // For portability, we won't actually allocate multiple textures; just verify that pipeline/layout creation with runtime array works.
    // Create descriptor set layout with variable descriptor count at binding 1
    VkDescriptorSetLayoutBinding b0{}; b0.binding=0; b0.descriptorType=VK_DESCRIPTOR_TYPE_SAMPLER; b0.descriptorCount=1; b0.stageFlags=VK_SHADER_STAGE_COMPUTE_BIT;
    VkDescriptorSetLayoutBinding b1{}; b1.binding=1; b1.descriptorType=VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE; b1.descriptorCount=8; b1.stageFlags=VK_SHADER_STAGE_COMPUTE_BIT; // runtime array; count is max
    VkDescriptorSetLayoutBinding b2{}; b2.binding=2; b2.descriptorType=VK_DESCRIPTOR_TYPE_STORAGE_IMAGE; b2.descriptorCount=1; b2.stageFlags=VK_SHADER_STAGE_COMPUTE_BIT;

    VkDescriptorBindingFlags flags1 = VK_DESCRIPTOR_BINDING_VARIABLE_DESCRIPTOR_COUNT_BIT | VK_DESCRIPTOR_BINDING_PARTIALLY_BOUND_BIT | VK_DESCRIPTOR_BINDING_UPDATE_AFTER_BIND_BIT;
    VkDescriptorSetLayoutBindingFlagsCreateInfo fci{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_BINDING_FLAGS_CREATE_INFO};
    std::vector<VkDescriptorBindingFlags> perBind = {0, flags1, 0};
    fci.bindingCount = (uint32_t)perBind.size();
    fci.pBindingFlags = perBind.data();

    VkDescriptorSetLayoutCreateInfo lci{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO};
    lci.pNext = &fci;
    lci.flags = VK_DESCRIPTOR_SET_LAYOUT_CREATE_UPDATE_AFTER_BIND_POOL_BIT;
    VkDescriptorSetLayoutBinding binds[3] = { b0, b1, b2 };
    lci.bindingCount = 3; lci.pBindings = binds;
    VkDescriptorSetLayout dsl; vkCreateDescriptorSetLayout(ctx.device(), &lci, nullptr, &dsl);

    VkPipelineLayoutCreateInfo plci{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};
    plci.setLayoutCount = 1; plci.pSetLayouts = &dsl;
    VkPipelineLayout pl; vkCreatePipelineLayout(ctx.device(), &plci, nullptr, &pl);

    // Shader module
    FILE* f = fopen("shaders/bindless_images.comp.spv","rb");
    if (!f){ std::cout << "compute_bindless_images: SKIP (no shader)\n"; return 0; }
    fseek(f,0,SEEK_END); long sz=ftell(f); fseek(f,0,SEEK_SET);
    std::vector<uint32_t> spirv(sz/4); fread(spirv.data(),1,sz,f); fclose(f);
    VkShaderModuleCreateInfo smci{VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO}; smci.codeSize = spirv.size()*4; smci.pCode=spirv.data();
    VkShaderModule sm; vkCreateShaderModule(ctx.device(), &smci, nullptr, &sm);

    VkPipelineShaderStageCreateInfo ss{VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO};
    ss.stage=VK_SHADER_STAGE_COMPUTE_BIT; ss.module=sm; ss.pName="main";
    VkComputePipelineCreateInfo pci{VK_STRUCTURE_TYPE_COMPUTE_PIPELINE_CREATE_INFO};
    pci.stage=ss; pci.layout=pl;
    VkPipeline pipe; vkCreateComputePipelines(ctx.device(), VK_NULL_HANDLE, 1, &pci, nullptr, &pipe);

    // Descriptor pool with UPDATE_AFTER_BIND
    VkDescriptorPoolSize sizes[3] = {
        {VK_DESCRIPTOR_TYPE_SAMPLER, 1},
        {VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE, 8},
        {VK_DESCRIPTOR_TYPE_STORAGE_IMAGE, 1}
    };
    VkDescriptorPoolCreateInfo dpci{VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO};
    dpci.flags = VK_DESCRIPTOR_POOL_CREATE_UPDATE_AFTER_BIND_BIT;
    dpci.maxSets = 1; dpci.poolSizeCount = 3; dpci.pPoolSizes = sizes;
    VkDescriptorPool dp; vkCreateDescriptorPool(ctx.device(), &dpci, nullptr, &dp);

    // Allocate with variable count
    uint32_t counts[1] = { 2 }; // we will bind 2 images (dummy, skipped)
    VkDescriptorSetVariableDescriptorCountAllocateInfo vci{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_VARIABLE_DESCRIPTOR_COUNT_ALLOCATE_INFO};
    vci.descriptorSetCount = 1; vci.pDescriptorCounts = counts;
    VkDescriptorSetAllocateInfo ai{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO};
    ai.pNext = &vci;
    ai.descriptorPool = dp; ai.descriptorSetCount=1; ai.pSetLayouts=&dsl;
    VkDescriptorSet ds; vkAllocateDescriptorSets(ctx.device(), &ai, &ds);

    // We won't actually run the dispatch (no images created); this sample is to ensure layout/pipeline/pool compile with variable counts
    vkDestroyDescriptorPool(ctx.device(), dp, nullptr);
    vkDestroyPipeline(ctx.device(), pipe, nullptr);
    vkDestroyShaderModule(ctx.device(), sm, nullptr);
    vkDestroyPipelineLayout(ctx.device(), pl, nullptr);
    vkDestroyDescriptorSetLayout(ctx.device(), dsl, nullptr);

    std::cout << "compute_bindless_images: OK\n";
    return 0;
}

#include <cassert>
#include <iostream>
#include "../src/physics/AABB.hpp"
using namespace voxelvk;

int main(){
    AABB a{0,0,0, 1,1,1}, b{0.5f,0.5f,0.5f, 1.5f,1.5f,1.5f}, c{2,2,2, 3,3,3};
    assert(intersect(a,b));
    assert(!intersect(a,c));
    VoxelGrid g{4,4,4, std::vector<uint8_t>(4*4*4, 0)};
    g.solid[(1*4 + 1)*4 + 1] = 1; // set voxel (1,1,1)
    AABB box{0.8f,0.8f,0.8f, 1.2f,1.2f,1.2f};
    assert(collideVoxel(g, box));
    std::cout << "physics: OK\n";
    return 0;
}

set(CTEST_PROJECT_NAME "voxelvk_full_build")

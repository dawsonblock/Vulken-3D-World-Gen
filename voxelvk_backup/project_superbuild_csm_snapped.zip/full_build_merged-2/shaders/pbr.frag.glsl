
#version 460
layout(location=0) in vec2 vUV;
layout(location=0) out vec4 outColor;

vec3 tonemapACES(vec3 x){
    float a=2.51; float b=0.03; float c=2.43; float d=0.59; float e=0.14;
    return clamp((x*(a*x+b))/(x*(c*x+d)+e), 0.0, 1.0);
}

void main(){
    // Simple gradient "sky"
    vec3 skyTop = vec3(0.1,0.3,0.8);
    vec3 skyBottom = vec3(0.7,0.9,1.0);
    vec3 sky = mix(skyBottom, skyTop, vUV.y);
    // Fake sun
    float sun = exp(-40.0 * length(vUV - vec2(0.8,0.8)));
    vec3 col = sky + vec3(1.0,0.9,0.6)*sun;
    outColor = vec4(tonemapACES(col), 1.0);
}

#version 450
layout(local_size_x=16, local_size_y=16) in;

layout(binding=0, rgba8) uniform writeonly image2D outImg;

void main(){
    ivec2 coord = ivec2(gl_GlobalInvocationID.xy);
    vec2 uv = vec2(coord) / vec2(imageSize(outImg));
    vec3 col = vec3(uv, 0.5);
    imageStore(outImg, coord, vec4(col, 1.0));
}

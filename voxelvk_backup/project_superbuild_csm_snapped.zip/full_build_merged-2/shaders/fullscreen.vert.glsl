#version 450
layout(location=0) out vec2 vUV;
const vec2 V[3] = vec2[3]( vec2(-1.0,-1.0), vec2(3.0,-1.0), vec2(-1.0,3.0) );
void main(){
    gl_Position = vec4(V[gl_VertexIndex], 0.0, 1.0);
    vUV = 0.5 * (gl_Position.xy + 1.0);
}

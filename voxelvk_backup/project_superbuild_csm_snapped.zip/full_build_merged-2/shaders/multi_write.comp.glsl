
#version 450
#extension GL_EXT_nonuniform_qualifier : enable
#extension GL_EXT_scalar_block_layout : enable
#extension GL_EXT_descriptor_indexing : enable

layout(local_size_x=64) in;
// Bindless runtime array of storage buffers
layout(set=0, binding=0, scalar) buffer Buffers[] {
    uint data[];
} outs;

layout(push_constant) uniform PC { uint N; } pc;

void main(){
    uint idx = gl_GlobalInvocationID.x;
    // write to all buffers modulo their size (assume sufficient length in test)
    for (uint i=0;i<pc.N;i++){
        outs[i].data[idx] = idx + i;
    }
}

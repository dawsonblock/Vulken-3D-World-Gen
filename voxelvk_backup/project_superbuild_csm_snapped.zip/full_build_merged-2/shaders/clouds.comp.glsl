#version 450
layout(local_size_x=8, local_size_y=8) in;
layout(set=0,binding=0, rgba16f) uniform image2D outTex;
float hash(vec2 p){ return fract(sin(dot(p, vec2(12.9898,78.233))) * 43758.5453); }
void main(){
    ivec2 coord = ivec2(gl_GlobalInvocationID.xy);
    vec2 uv = vec2(coord)/vec2(imageSize(outTex));
    float n = hash(uv*256.0);
    vec3 c = mix(vec3(0.9), vec3(1.0), smoothstep(0.5,0.7,n));
    imageStore(outTex, coord, vec4(c,1.0));
}

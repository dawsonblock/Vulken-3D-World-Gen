#version 450
layout(location=0) out vec4 outColor;
void main(){
    // Tiny atmospheric gradient placeholder
    float t = gl_FragCoord.y / 1080.0;
    outColor = vec4(mix(vec3(0.05,0.1,0.2), vec3(0.5,0.7,1.0), t), 1.0);
}

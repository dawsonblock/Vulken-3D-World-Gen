#version 450
// Minimal split-sum BRDF integration LUT (hemisphere importance sampling placeholder)
// Writes RG8 output for simplicity.
layout(local_size_x=8, local_size_y=8) in;
layout(binding=0, rgba8) uniform writeonly image2D outLUT;

float saturate(float x){ return clamp(x,0.0,1.0); }

void main(){
    ivec2 dim = imageSize(outLUT);
    ivec2 id = ivec2(gl_GlobalInvocationID.xy);
    if (id.x >= dim.x || id.y >= dim.y) return;
    // Fake integration: encode roughness (y) and NdotV (x) in a visible gradient
    float roughness = float(id.y) / float(dim.y-1);
    float ndv = float(id.x) / float(dim.x-1);
    float r = sqrt(roughness);
    float g = sqrt(ndv);
    imageStore(outLUT, id, vec4(r, g, 0.0, 1.0));
}

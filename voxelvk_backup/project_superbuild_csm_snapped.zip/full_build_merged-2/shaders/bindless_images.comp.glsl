#version 450
#extension GL_EXT_nonuniform_qualifier : enable
#extension GL_EXT_descriptor_indexing : enable
layout(local_size_x=8, local_size_y=8) in;

layout(set=0, binding=0) uniform sampler samp0;
layout(set=0, binding=1) uniform texture2D images[]; // runtime array
layout(push_constant) uniform Push { int count; } pc;

layout(set=0, binding=2, rgba8) uniform writeonly image2D outImage;

void main(){
    ivec2 uv = ivec2(gl_GlobalInvocationID.xy);
    vec3 acc = vec3(0.0);
    for (int i=0;i<pc.count;i++){
        vec4 c = texture(sampler2D(images[nonuniformEXT(i)], samp0), (vec2(uv)%vec2(64))/64.0);
        acc += c.rgb;
    }
    vec3 avg = acc / max(1, pc.count);
    imageStore(outImage, uv, vec4(avg, 1.0));
}

#version 450
// If descriptor indexing available, we can bind a runtime array; otherwise single binding.
layout(local_size_x = 64) in;

#ifdef BINDLESS
layout(set=0, binding=0) buffer Data[] { float x[]; } buffers[];
layout(push_constant) uniform PC { uint bufIndex; uint count; } pc;
#else
layout(set=0, binding=0) buffer Data { float x[]; } buf;
layout(push_constant) uniform PC { uint count; } pc;
#endif

void main(){
    uint i = gl_GlobalInvocationID.x;
    if (i >= pc.count) return;
#ifdef BINDLESS
    buffers[pc.bufIndex].x[i] += 1.0;
#else
    buf.x[i] += 1.0;
#endif
}

#version 450
layout(location=0) in vec3 vNormal;
layout(location=1) in vec3 vViewDir;
layout(location=0) out vec4 outColor;
layout(set=0,binding=0) uniform sampler2D albedoTex;
layout(set=0,binding=1) uniform sampler2D roughTex;
layout(set=0,binding=2) uniform sampler2D metalTex;
const float PI = 3.14159265;
vec3 fresnelSchlick(float cosTheta, vec3 F0){ return F0 + (1.0 - F0)*pow(1.0 - cosTheta, 5.0); }
void main(){
    vec3 N = normalize(vNormal);
    vec3 V = normalize(vViewDir);
    vec3 albedo = texture(albedoTex, vec2(0.5)).rgb;
    float rough = texture(roughTex, vec2(0.5)).r;
    float metal = texture(metalTex, vec2(0.5)).r;
    vec3 F0 = mix(vec3(0.04), albedo, metal);
    vec3 L = normalize(vec3(0.3,0.7,0.2));
    vec3 H = normalize(V+L);
    float NoL = max(dot(N,L),0.0);
    float NoV = max(dot(N,V),0.0);
    float NoH = max(dot(N,H),0.0);
    float VoH = max(dot(V,H),0.0);
    vec3 F = fresnelSchlick(VoH, F0);
    float D = max(rough*rough, 0.04);
    float G = clamp(NoL*NoV, 0.0, 1.0);
    vec3 spec = (D*F*G)/max(4.0*NoL*NoV, 0.001);
    vec3 diff = (1.0 - F) * (1.0 - metal) * albedo / PI;
    vec3 color = (diff + spec) * NoL;
    outColor = vec4(color,1.0);
}

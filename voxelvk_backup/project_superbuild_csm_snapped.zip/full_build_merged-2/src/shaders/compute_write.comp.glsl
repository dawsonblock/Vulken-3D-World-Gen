
#version 450
layout(local_size_x = 1, local_size_y = 1, local_size_z = 1) in;

layout(set = 0, binding = 0) buffer OutBuf {
    uint data[];
} outbuf;

void main() {
    // Write a simple signature
    outbuf.data[0] = 0xC0FFEEu;
    outbuf.data[1] = 0xFACECAFEu;
    outbuf.data[2] = 0xDEADBEEFu;
    outbuf.data[3] = 0x12345678u;
}

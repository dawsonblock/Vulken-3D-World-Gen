#pragma once
#include <cstdint>
#include <vector>
#include <algorithm>

namespace voxelvk {

struct AABB {
    float minx, miny, minz;
    float maxx, maxy, maxz;
};

inline bool intersect(const AABB& a, const AABB& b){
    return !(a.maxx < b.minx || a.minx > b.maxx ||
             a.maxy < b.miny || a.miny > b.maxy ||
             a.maxz < b.minz || a.minz > b.maxz);
}

// Simple voxel grid collision: returns true if any solid voxel overlaps the AABB
struct VoxelGrid {
    int sx, sy, sz; // dimensions
    std::vector<uint8_t> solid; // 1=solid, 0=empty
    bool isSolid(int x,int y,int z) const {
        if(x<0||y<0||z<0||x>=sx||y>=sy||z>=sz) return false;
        return solid[(z*sy + y)*sx + x] != 0;
    }
};

inline bool collideVoxel(const VoxelGrid& g, const AABB& box){
    int minx = std::max(0, (int)std::floor(box.minx));
    int miny = std::max(0, (int)std::floor(box.miny));
    int minz = std::max(0, (int)std::floor(box.minz));
    int maxx = std::min(g.sx-1, (int)std::floor(box.maxx));
    int maxy = std::min(g.sy-1, (int)std::floor(box.maxy));
    int maxz = std::min(g.sz-1, (int)std::floor(box.maxz));
    for (int z=minz; z<=maxz; ++z)
    for (int y=miny; y<=maxy; ++y)
    for (int x=minx; x<=maxx; ++x){
        if (g.isSolid(x,y,z)) return true;
    }
    return false;
}

} // namespace voxelvk

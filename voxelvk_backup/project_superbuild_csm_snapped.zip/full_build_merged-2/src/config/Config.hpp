
#pragma once
#include <string>

namespace voxelvk {
struct Config { unsigned short metrics_port = 9090; };
}

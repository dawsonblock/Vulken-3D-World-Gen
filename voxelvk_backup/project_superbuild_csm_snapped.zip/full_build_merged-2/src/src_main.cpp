#include <iostream>
#include <thread>
#include <chrono>
#include "ai/CapsuleBrain.hpp"
#include "vk/VulkanContext.hpp"

using namespace voxelvk;

int main(){
    VulkanContext ctx(/*validation*/false);
    ctx.submitOneShot(ctx.queues().graphics, ctx.graphicsQueue(), [](VkCommandBuffer){ /*noop*/ });
    CapsuleBrain brain;
    brain.start();
    brain.submit_goal("boot: initialize world");
    std::this_thread::sleep_for(std::chrono::milliseconds(50));
    brain.stop();
    std::cout << "voxelvk_headless: OK\n";
    return 0;
}

#pragma once
#include <future>
#include <queue>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <functional>
#include <vector>
#include <atomic>

namespace voxelvk {

class ThreadPool {
public:
    explicit ThreadPool(size_t threads = std::thread::hardware_concurrency()) {
        if (threads == 0) threads = 1;
        for (size_t i = 0; i < threads; ++i) {
            workers_.emplace_back([this]{
                for(;;){
                    std::function<void()> job;
                    {
                        std::unique_lock<std::mutex> lk(mtx_);
                        cv_.wait(lk, [this]{ return stopping_.load() || !queue_.empty(); });
                        if (stopping_.load() && queue_.empty()) return;
                        job = std::move(queue_.front());
                        queue_.pop();
                    }
                    job();
                }
            });
        }
    }

    ~ThreadPool(){ shutdown(); }

    template<class F, class... Args>
    auto submit(F&& f, Args&&... args) -> std::future<decltype(f(args...))> {
        using R = decltype(f(args...));
        auto task = std::make_shared<std::packaged_task<R()>>(std::bind(std::forward<F>(f), std::forward<Args>(args)...));
        std::future<R> res = task->get_future();
        {
            std::lock_guard<std::mutex> lk(mtx_);
            if (stopping_) throw std::runtime_error("ThreadPool stopped");
            queue_.emplace([task]{ (*task)(); });
        }
        cv_.notify_one();
        return res;
    }

    void shutdown(){
        bool expected = false;
        if (!stopping_.compare_exchange_strong(expected, true)) return;
        cv_.notify_all();
        for (auto& t : workers_) if (t.joinable()) t.join();
    }

private:
    std::vector<std::thread> workers_;
    std::queue<std::function<void()>> queue_;
    std::mutex mtx_;
    std::condition_variable cv_;
    std::atomic<bool> stopping_{false};
};

} // namespace voxelvk

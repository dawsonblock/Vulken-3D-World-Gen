#include "ComputeSample.hpp"
#include "../vk/Transfer.hpp"
#include "../vk/Descriptors.hpp"
#include <fstream>
#include <stdexcept>
#include <iostream>

namespace voxelvk {

static std::vector<char> readFile(const std::string& path){
    std::ifstream f(path, std::ios::binary);
    if(!f) throw std::runtime_error("Failed to open file: " + path);
    return std::vector<char>(std::istreambuf_iterator<char>(f), {});
}

int run_compute_sample(VulkanContext& ctx, const char* shaderDir){
    auto device = ctx.device();
    auto phys = ctx.physical();

    // Create a small storage buffer (16 bytes)
    const VkDeviceSize sz = 16;
    auto devBuf = TransferHelper::createBuffer(device, phys, sz,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_SRC_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT, [&](uint32_t t, VkMemoryPropertyFlags p){ return ctx.findMemoryType(t, p); });

    auto hostBuf = TransferHelper::createBuffer(device, phys, sz,
        VK_BUFFER_USAGE_TRANSFER_DST_BIT | VK_BUFFER_USAGE_TRANSFER_SRC_BIT,
        VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT,
        [&](uint32_t t, VkMemoryPropertyFlags p){ return ctx.findMemoryType(t, p); });

    // Descriptor pool
    DescriptorAllocator alloc; alloc.init(device, ctx.features().updateAfterBind);

    // Descriptor set layout
    VkDescriptorSetLayoutBinding b{};
    b.binding = 0;
    b.descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
    b.descriptorCount = 1;
    b.stageFlags = VK_SHADER_STAGE_COMPUTE_BIT;

    VkDescriptorSetLayoutCreateInfo lci{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO};
    lci.bindingCount = 1; lci.pBindings = &b;
    if (ctx.features().updateAfterBind){
        lci.flags |= VK_DESCRIPTOR_SET_LAYOUT_CREATE_UPDATE_AFTER_BIND_POOL_BIT;
    }
    VkDescriptorSetLayout layout;
    if (vkCreateDescriptorSetLayout(device, &lci, nullptr, &layout) != VK_SUCCESS)
        throw std::runtime_error("vkCreateDescriptorSetLayout failed");

    // Allocate a descriptor set
    VkDescriptorSetAllocateInfo sai{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO};
    sai.descriptorPool = alloc.pool();
    sai.descriptorSetCount = 1;
    sai.pSetLayouts = &layout;
    VkDescriptorSet set;
    if (vkAllocateDescriptorSets(device, &sai, &set) != VK_SUCCESS)
        throw std::runtime_error("vkAllocateDescriptorSets failed");

    // Update buffer binding
    VkDescriptorBufferInfo bi{}; bi.buffer = devBuf.buffer; bi.offset = 0; bi.range = sz;
    VkWriteDescriptorSet write{VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET};
    write.dstSet = set; write.dstBinding = 0; write.descriptorCount = 1;
    write.descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
    write.pBufferInfo = &bi;
    vkUpdateDescriptorSets(device, 1, &write, 0, nullptr);

    // Pipeline layout
    VkPipelineLayoutCreateInfo plci{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};
    plci.setLayoutCount = 1; plci.pSetLayouts = &layout;
    VkPipelineLayout pipelineLayout;
    if (vkCreatePipelineLayout(device, &plci, nullptr, &pipelineLayout) != VK_SUCCESS)
        throw std::runtime_error("vkCreatePipelineLayout failed");

    // Shader module
    std::string spvPath = std::string(shaderDir) + "/compute_write.comp.glsl.spv";
    auto code = readFile(spvPath);
    VkShaderModuleCreateInfo smci{VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO};
    smci.codeSize = code.size();
    smci.pCode = reinterpret_cast<const uint32_t*>(code.data());
    VkShaderModule mod;
    if (vkCreateShaderModule(device, &smci, nullptr, &mod) != VK_SUCCESS)
        throw std::runtime_error("vkCreateShaderModule failed");

    // Compute pipeline
    VkPipelineShaderStageCreateInfo stage{VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO};
    stage.stage = VK_SHADER_STAGE_COMPUTE_BIT;
    stage.module = mod;
    stage.pName = "main";

    VkComputePipelineCreateInfo pci{VK_STRUCTURE_TYPE_COMPUTE_PIPELINE_CREATE_INFO};
    pci.stage = stage;
    pci.layout = pipelineLayout;

    VkPipeline pipeline;
    if (vkCreateComputePipelines(device, VK_NULL_HANDLE, 1, &pci, nullptr, &pipeline) != VK_SUCCESS)
        throw std::runtime_error("vkCreateComputePipelines failed");

    // Command buffer
    VkCommandPoolCreateInfo cpi{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
    cpi.queueFamilyIndex = ctx.families().graphics;
    cpi.flags = VK_COMMAND_POOL_CREATE_TRANSIENT_BIT | VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
    VkCommandPool pool; vkCreateCommandPool(device, &cpi, nullptr, &pool);

    VkCommandBufferAllocateInfo cai{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
    cai.commandPool = pool; cai.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY; cai.commandBufferCount = 1;
    VkCommandBuffer cmd; vkAllocateCommandBuffers(device, &cai, &cmd);

    VkCommandBufferBeginInfo bi2{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
    vkBeginCommandBuffer(cmd, &bi2);
    vkCmdBindPipeline(cmd, VK_PIPELINE_BIND_POINT_COMPUTE, pipeline);
    vkCmdBindDescriptorSets(cmd, VK_PIPELINE_BIND_POINT_COMPUTE, pipelineLayout, 0, 1, &set, 0, nullptr);

    // Barrier: ensure storage writes visible before copy
    vkCmdDispatch(cmd, 1,1,1);

    VkMemoryBarrier2 memBarrier{VK_STRUCTURE_TYPE_MEMORY_BARRIER_2};
    memBarrier.srcStageMask = VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT;
    memBarrier.srcAccessMask = VK_ACCESS_2_SHADER_WRITE_BIT;
    memBarrier.dstStageMask = VK_PIPELINE_STAGE_2_TRANSFER_BIT;
    memBarrier.dstAccessMask = VK_ACCESS_2_TRANSFER_READ_BIT;

    VkDependencyInfo dep{VK_STRUCTURE_TYPE_DEPENDENCY_INFO};
    dep.memoryBarrierCount = 1; dep.pMemoryBarriers = &memBarrier;
    auto vkCmdPipelineBarrier2KHR = (PFN_vkCmdPipelineBarrier2)vkGetDeviceProcAddr(device, "vkCmdPipelineBarrier2");
    if (vkCmdPipelineBarrier2KHR) vkCmdPipelineBarrier2KHR(cmd, &dep);

    // Copy to host buffer
    VkBufferCopy cpy{0,0,sz};
    vkCmdCopyBuffer(cmd, devBuf.buffer, hostBuf.buffer, 1, &cpy);

    vkEndCommandBuffer(cmd);

    // If timeline supported, use it, else fence
    VkTimelineSemaphoreSubmitInfo timelineInfo{VK_STRUCTURE_TYPE_TIMELINE_SEMAPHORE_SUBMIT_INFO};
    uint64_t signalVal = 1;
    VkSemaphore timeline = VK_NULL_HANDLE;
    VkFence fence = VK_NULL_HANDLE;

    VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO};
    si.commandBufferCount = 1; si.pCommandBuffers = &cmd;

    if (ctx.features().timelineSemaphore){
        timeline = ctx.createTimelineSemaphore(0);
        si.pNext = &timelineInfo;
        si.signalSemaphoreCount = 1;
        si.pSignalSemaphores = &timeline;
        timelineInfo.signalSemaphoreValueCount = 1;
        timelineInfo.pSignalSemaphoreValues = &signalVal;
        vkQueueSubmit(ctx.graphicsQueue(), 1, &si, VK_NULL_HANDLE);
        ctx.waitTimeline(timeline, 1);
    } else {
        VkFenceCreateInfo fci{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};
        vkCreateFence(device, &fci, nullptr, &fence);
        vkQueueSubmit(ctx.graphicsQueue(), 1, &si, fence);
        vkWaitForFences(device, 1, &fence, VK_TRUE, UINT64_MAX);
    }

    // Read back
    uint32_t* p = (uint32_t*)TransferHelper::map(device, hostBuf);
    uint32_t a=p[0], b=p[1], c=p[2], d=p[3];
    TransferHelper::unmap(device, hostBuf);

    std::cout << "Compute out: " << std::hex << a << " " << b << " " << c << " " << d << std::dec << std::endl;

    // Cleanup
    if (timeline) vkDestroySemaphore(device, timeline, nullptr);
    if (fence) vkDestroyFence(device, fence, nullptr);
    vkDestroyCommandPool(device, pool, nullptr);
    vkDestroyPipeline(device, pipeline, nullptr);
    vkDestroyShaderModule(device, mod, nullptr);
    vkDestroyPipelineLayout(device, pipelineLayout, nullptr);
    vkDestroyDescriptorSetLayout(device, layout, nullptr);
    alloc.destroy(device);
    TransferHelper::destroyBuffer(device, hostBuf);
    TransferHelper::destroyBuffer(device, devBuf);

    return 0;
}

} // namespace voxelvk

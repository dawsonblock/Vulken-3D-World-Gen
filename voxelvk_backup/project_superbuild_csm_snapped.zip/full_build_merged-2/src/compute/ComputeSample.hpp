#pragma once
#include "../vk/VulkanContext.hpp"

namespace voxelvk {
int run_compute_sample(VulkanContext& ctx, const char* shaderDir);
} // namespace voxelvk

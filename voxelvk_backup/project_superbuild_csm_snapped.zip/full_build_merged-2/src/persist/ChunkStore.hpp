#pragma once
#include <string>
#include <vector>
#include <cstdint>

namespace voxelvk {

struct Chunk {
    int x=0,y=0,z=0;
    int sx=0, sy=0, sz=0;
    std::vector<uint8_t> voxels; // simple density or material index
};

class ChunkStore {
public:
    bool save(const std::string& path, const Chunk& c);
    bool load(const std::string& path, Chunk& out);
};

} // namespace voxelvk

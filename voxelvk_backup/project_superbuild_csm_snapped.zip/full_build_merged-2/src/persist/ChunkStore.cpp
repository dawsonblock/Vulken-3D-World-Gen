#include "ChunkStore.hpp"
#include <cstdio>

namespace voxelvk {

static bool writeAll(FILE* f, const void* p, size_t sz){ return std::fwrite(p,1,sz,f)==sz; }
static bool readAll(FILE* f, void* p, size_t sz){ return std::fread(p,1,sz,f)==sz; }

bool ChunkStore::save(const std::string& path, const Chunk& c){
    FILE* f = std::fopen(path.c_str(), "wb");
    if(!f) return false;
    uint32_t magic = 0x564F5843; // 'VOXC'
    if(!writeAll(f, &magic, sizeof(magic))) { std::fclose(f); return false; }
    if(!writeAll(f, &c.x, sizeof(c.x))) { std::fclose(f); return false; }
    if(!writeAll(f, &c.y, sizeof(c.y))) { std::fclose(f); return false; }
    if(!writeAll(f, &c.z, sizeof(c.z))) { std::fclose(f); return false; }
    if(!writeAll(f, &c.sx, sizeof(c.sx))) { std::fclose(f); return false; }
    if(!writeAll(f, &c.sy, sizeof(c.sy))) { std::fclose(f); return false; }
    if(!writeAll(f, &c.sz, sizeof(c.sz))) { std::fclose(f); return false; }
    uint64_t n = c.voxels.size();
    if(!writeAll(f, &n, sizeof(n))) { std::fclose(f); return false; }
    if(n && !writeAll(f, c.voxels.data(), n)) { std::fclose(f); return false; }
    std::fclose(f); return true;
}

bool ChunkStore::load(const std::string& path, Chunk& out){
    FILE* f = std::fopen(path.c_str(), "rb");
    if(!f) return false;
    uint32_t magic=0; if(!readAll(f,&magic,sizeof(magic))) { std::fclose(f); return false; }
    if(magic != 0x564F5843){ std::fclose(f); return false; }
    if(!readAll(f,&out.x,sizeof(out.x))) { std::fclose(f); return false; }
    if(!readAll(f,&out.y,sizeof(out.y))) { std::fclose(f); return false; }
    if(!readAll(f,&out.z,sizeof(out.z))) { std::fclose(f); return false; }
    if(!readAll(f,&out.sx,sizeof(out.sx))) { std::fclose(f); return false; }
    if(!readAll(f,&out.sy,sizeof(out.sy))) { std::fclose(f); return false; }
    if(!readAll(f,&out.sz,sizeof(out.sz))) { std::fclose(f); return false; }
    uint64_t n=0; if(!readAll(f,&n,sizeof(n))) { std::fclose(f); return false; }
    out.voxels.resize((size_t)n);
    if(n && !readAll(f,out.voxels.data(),n)) { std::fclose(f); return false; }
    std::fclose(f); return true;
}

} // namespace voxelvk

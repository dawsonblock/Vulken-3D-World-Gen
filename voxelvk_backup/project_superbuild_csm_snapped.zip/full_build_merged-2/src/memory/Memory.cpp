#include "Memory.hpp"
using namespace voxelvk;

void MemoryStore::put(const std::string& key, const std::string& value){
    std::lock_guard<std::mutex> lk(mtx_);
    auto& it = mem_[key];
    it.key = key;
    it.value = value;
    it.relevance = 1.0;
    it.last_access = std::chrono::steady_clock::now();
}

std::string MemoryStore::get(const std::string& key){
    std::lock_guard<std::mutex> lk(mtx_);
    auto it = mem_.find(key);
    if (it == mem_.end()) return {};
    it->second.last_access = std::chrono::steady_clock::now();
    return it->second.value;
}

void MemoryStore::decay(double factor){
    std::lock_guard<std::mutex> lk(mtx_);
    for (auto &kv : mem_) {
        kv.second.relevance *= factor;
    }
}

std::vector<MemoryItem> MemoryStore::dump() const{
    std::lock_guard<std::mutex> lk(mtx_);
    std::vector<MemoryItem> out; out.reserve(mem_.size());
    for (auto &kv : mem_) out.push_back(kv.second);
    return out;
}

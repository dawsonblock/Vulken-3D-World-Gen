#pragma once
#include <string>
#include <unordered_map>
#include <vector>
#include <chrono>
#include <mutex>

namespace voxelvk {

struct MemoryItem {
    std::string key;
    std::string value;
    double relevance = 1.0;
    std::chrono::steady_clock::time_point last_access = std::chrono::steady_clock::now();
};

class MemoryStore {
public:
    void put(const std::string& key, const std::string& value);
    std::string get(const std::string& key);
    void decay(double factor);
    std::vector<MemoryItem> dump() const;
private:
    mutable std::mutex mtx_;
    std::unordered_map<std::string, MemoryItem> mem_;
};

} // namespace voxelvk

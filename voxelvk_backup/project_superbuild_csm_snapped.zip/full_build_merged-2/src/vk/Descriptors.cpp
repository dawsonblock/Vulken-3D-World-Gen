#include "Descriptors.hpp"

namespace voxelvk {

void DescriptorAllocator::init(VkDevice device, bool updateAfterBind){
    std::vector<VkDescriptorPoolSize> sizes = {
        {VK_DESCRIPTOR_TYPE_STORAGE_BUFFER, 1024},
        {VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER, 1024},
        {VK_DESCRIPTOR_TYPE_STORAGE_IMAGE, 512},
        {VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER, 256}
    };
    VkDescriptorPoolCreateFlags flags = VK_DESCRIPTOR_POOL_CREATE_FREE_DESCRIPTOR_SET_BIT;
    if (updateAfterBind) flags |= VK_DESCRIPTOR_POOL_CREATE_UPDATE_AFTER_BIND_BIT;
    VkDescriptorPoolCreateInfo ci{VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO};
    ci.poolSizeCount = (uint32_t)sizes.size();
    ci.pPoolSizes = sizes.data();
    ci.maxSets = 2048;
    ci.flags = flags;
    if (vkCreateDescriptorPool(device, &ci, nullptr, &pool_) != VK_SUCCESS)
        throw std::runtime_error("vkCreateDescriptorPool failed");
}

void DescriptorAllocator::destroy(VkDevice device){
    if (pool_) { vkDestroyDescriptorPool(device, pool_, nullptr); pool_ = VK_NULL_HANDLE; }
}

} // namespace voxelvk

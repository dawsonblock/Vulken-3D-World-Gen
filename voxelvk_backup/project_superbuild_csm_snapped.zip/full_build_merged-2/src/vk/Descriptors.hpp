#pragma once
#include <vulkan/vulkan.h>
#include <vector>
#include <stdexcept>

namespace voxelvk {

class DescriptorAllocator {
public:
    void init(VkDevice device, bool updateAfterBind);
    void destroy(VkDevice device);
    VkDescriptorPool pool() const { return pool_; }

private:
    VkDescriptorPool pool_{VK_NULL_HANDLE};
};

} // namespace voxelvk

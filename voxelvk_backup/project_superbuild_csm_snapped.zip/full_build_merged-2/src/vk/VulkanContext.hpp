#pragma once
#include <vulkan/vulkan.h>
#include <functional>
#include <vector>
#include <string>
#include <cstdint>

namespace voxelvk {

struct QueueFamilies {
    uint32_t graphics = 0;
    uint32_t transfer = 0;
    bool hasTransfer = false;
};

struct VulkanFeatures {
    bool hasTimeline = false;
    bool hasSync2 = false;
    bool hasDescriptorIndexing = false;
    bool hasMaintenance4 = false;
    uint32_t apiMajor = 1;
    uint32_t apiMinor = 2;
};

class VulkanContext {
public:
    VulkanContext(bool enableValidation=false);
    ~VulkanContext();

    VkInstance instance() const { return instance_; }
    VkDevice device() const { return device_; }
    VkPhysicalDevice physical() const { return physical_; }
    VkQueue graphicsQueue() const { return graphicsQ_; }
    VkQueue transferQueue() const { return transferQ_; }
    const QueueFamilies& queues() const { return qf_; }
    const VulkanFeatures& features() const { return feats_; }

    // Memory helpers
    uint32_t findMemoryType(uint32_t typeBits, VkMemoryPropertyFlags props) const;
    void createBuffer(VkDeviceSize size, VkBufferUsageFlags usage, VkMemoryPropertyFlags props,
                      VkBuffer& buffer, VkDeviceMemory& memory);
    void destroyBuffer(VkBuffer buf, VkDeviceMemory mem);

    // One-shot submits
    void submitOneShot(uint32_t family, VkQueue queue, const std::function<void(VkCommandBuffer)>& record);

    // Timeline helpers (available even if fallback path used; no-ops if unsupported)
    VkSemaphore createTimelineSemaphore(uint64_t initialValue = 0);
    void waitTimeline(VkSemaphore sem, uint64_t value);
    void signalTimeline(VkQueue queue, VkSemaphore sem, uint64_t value);

    // Transfer→Compute→Transfer chain using a single timeline semaphore
    // recordCopyUp: record staging → device-local copy
    // recordCompute: record compute dispatch
    // recordCopyDown: record device-local → staging copy
    void transferComputeTransferChain(
        const std::function<void(VkCommandBuffer)>& recordCopyUp,
        const std::function<void(VkCommandBuffer)>& recordCompute,
        const std::function<void(VkCommandBuffer)>& recordCopyDown);

    // Descriptor pool (bindless-capable if features allow)
    VkDescriptorPool descriptorPool() const { return descPool_; }

private:
    bool validation_ = false;
    VkInstance instance_ = VK_NULL_HANDLE;
    VkDebugUtilsMessengerEXT debugMessenger_ = VK_NULL_HANDLE;
    VkPhysicalDevice physical_ = VK_NULL_HANDLE;
    VkDevice device_ = VK_NULL_HANDLE;
    QueueFamilies qf_{};
    VulkanFeatures feats_{};

    VkCommandPool graphicsPool_ = VK_NULL_HANDLE;
    VkCommandPool transferPool_ = VK_NULL_HANDLE;
    VkDescriptorPool descPool_ = VK_NULL_HANDLE;

    // function pointers for sync2 if present
    PFN_vkQueueSubmit2 pfn_vkQueueSubmit2_ = nullptr;
    PFN_vkCmdPipelineBarrier2 pfn_vkCmdPipelineBarrier2_ = nullptr;

    void createInstance();
    void setupDebug();
    void pickPhysicalDevice();
    void createDevice();
    void createPools();
    void createDescriptorPool();
    void destroyPools();
    void destroyDescriptorPool();
    void destroyDevice();
    void destroyInstance();

    static VKAPI_ATTR VkBool32 VKAPI_CALL debugCallback(
        VkDebugUtilsMessageSeverityFlagBitsEXT severity,
        VkDebugUtilsMessageTypeFlagsEXT types,
        const VkDebugUtilsMessengerCallbackDataEXT* pCallbackData,
        void* pUserData);
};

} // namespace voxelvk

#pragma once
#include <vulkan/vulkan.h>
#include <cstdint>

namespace voxelvk {

struct Buffer {
    VkBuffer buffer = VK_NULL_HANDLE;
    VkDeviceMemory memory = VK_NULL_HANDLE;
    VkDeviceSize size = 0;
};

class TransferHelper {
public:
    static Buffer createBuffer(VkDevice device, VkPhysicalDevice phys, VkDeviceSize size,
                               VkBufferUsageFlags usage, VkMemoryPropertyFlags props,
                               uint32_t (*findMemoryType)(uint32_t, VkMemoryPropertyFlags));
    static void destroyBuffer(VkDevice device, const Buffer& b);

    static void copyBuffer(VkDevice device, VkQueue q, uint32_t family,
                           VkBuffer src, VkBuffer dst, VkDeviceSize size);

    static void* map(VkDevice device, const Buffer& b);
    static void unmap(VkDevice device, const Buffer& b);
};

} // namespace voxelvk

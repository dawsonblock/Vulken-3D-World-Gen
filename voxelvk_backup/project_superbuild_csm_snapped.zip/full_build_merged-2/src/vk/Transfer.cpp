#include "Transfer.hpp"
#include <stdexcept>

namespace voxelvk {

Buffer TransferHelper::createBuffer(VkDevice device, VkPhysicalDevice phys, VkDeviceSize size,
                                    VkBufferUsageFlags usage, VkMemoryPropertyFlags props,
                                    uint32_t (*findMemoryType)(uint32_t, VkMemoryPropertyFlags))
{
    Buffer out; out.size = size;
    VkBufferCreateInfo bi{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};
    bi.size = size;
    bi.usage = usage;
    bi.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    if (vkCreateBuffer(device, &bi, nullptr, &out.buffer) != VK_SUCCESS)
        throw std::runtime_error("vkCreateBuffer failed");

    VkMemoryRequirements req{};
    vkGetBufferMemoryRequirements(device, out.buffer, &req);

    VkMemoryAllocateInfo ai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
    ai.allocationSize = req.size;
    ai.memoryTypeIndex = findMemoryType(req.memoryTypeBits, props);
    if (vkAllocateMemory(device, &ai, nullptr, &out.memory) != VK_SUCCESS)
        throw std::runtime_error("vkAllocateMemory failed");
    vkBindBufferMemory(device, out.buffer, out.memory, 0);
    return out;
}

void TransferHelper::destroyBuffer(VkDevice device, const Buffer& b){
    if (b.buffer) vkDestroyBuffer(device, b.buffer, nullptr);
    if (b.memory) vkFreeMemory(device, b.memory, nullptr);
}

void TransferHelper::copyBuffer(VkDevice device, VkQueue q, uint32_t family,
                                VkBuffer src, VkBuffer dst, VkDeviceSize size)
{
    VkCommandPoolCreateInfo pci{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
    pci.queueFamilyIndex = family;
    pci.flags = VK_COMMAND_POOL_CREATE_TRANSIENT_BIT | VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
    VkCommandPool pool; vkCreateCommandPool(device, &pci, nullptr, &pool);

    VkCommandBufferAllocateInfo ai{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
    ai.commandPool = pool; ai.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY; ai.commandBufferCount = 1;
    VkCommandBuffer cmd; vkAllocateCommandBuffers(device, &ai, &cmd);

    VkCommandBufferBeginInfo bi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
    vkBeginCommandBuffer(cmd, &bi);

    VkBufferCopy cpy{}; cpy.srcOffset = 0; cpy.dstOffset = 0; cpy.size = size;
    vkCmdCopyBuffer(cmd, src, dst, 1, &cpy);

    vkEndCommandBuffer(cmd);

    VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO};
    si.commandBufferCount = 1; si.pCommandBuffers = &cmd;
    vkQueueSubmit(q, 1, &si, VK_NULL_HANDLE);
    vkQueueWaitIdle(q);

    vkFreeCommandBuffers(device, pool, 1, &cmd);
    vkDestroyCommandPool(device, pool, nullptr);
}

void* TransferHelper::map(VkDevice device, const Buffer& b){
    void* p=nullptr; vkMapMemory(device, b.memory, 0, b.size, 0, &p); return p;
}
void TransferHelper::unmap(VkDevice device, const Buffer& b){
    vkUnmapMemory(device, b.memory);
}

} // namespace voxelvk

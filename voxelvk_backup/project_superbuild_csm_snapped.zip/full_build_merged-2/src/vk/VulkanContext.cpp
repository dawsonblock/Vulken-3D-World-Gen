#include "VulkanContext.hpp"
#include <cstdlib>
#include <cstring>
#include <stdexcept>
#include <iostream>

namespace voxelvk {

static bool getEnvFlag(const char* name){
#ifdef _WIN32
    size_t len=0; getenv_s(&len, nullptr, 0, name);
    if(len==0) return false; std::string v(len,'\0'); getenv_s(&len, v.data(), len, name);
    return !v.empty() && v[0]!='0';
#else
    const char* v = std::getenv(name);
    return v && v[0] && v[0] != '0';
#endif
}

VulkanContext::VulkanContext(bool enableValidation){
    validation_ = enableValidation || getEnvFlag("VOXELVK_VALIDATION");
    createInstance();
    if (validation_) setupDebug();
    pickPhysicalDevice();
    createDevice();
    createPools();
    createDescriptorPool();
}

VulkanContext::~VulkanContext(){
    destroyDescriptorPool();
    destroyPools();
    destroyDevice();
    if (validation_ && debugMessenger_) {
        auto pfn = (PFN_vkDestroyDebugUtilsMessengerEXT)vkGetInstanceProcAddr(instance_, "vkDestroyDebugUtilsMessengerEXT");
        if (pfn) pfn(instance_, debugMessenger_, nullptr);
        debugMessenger_ = VK_NULL_HANDLE;
    }
    destroyInstance();
}

void VulkanContext::createInstance(){
    VkApplicationInfo app{};
    app.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
    app.pApplicationName = "VoxelVK Headless";
    app.apiVersion = VK_API_VERSION_1_3;

    VkInstanceCreateInfo ci{ VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO };
    ci.pApplicationInfo = &app;

    std::vector<const char*> layers;
    if (validation_) layers.push_back("VK_LAYER_KHRONOS_validation");
    if (!layers.empty()) { ci.enabledLayerCount = (uint32_t)layers.size(); ci.ppEnabledLayerNames = layers.data(); }

    std::vector<const char*> exts;
    exts.push_back(VK_EXT_DEBUG_UTILS_EXTENSION_NAME); // harmless if validation_ false; messenger optional
    ci.enabledExtensionCount = (uint32_t)exts.size();
    ci.ppEnabledExtensionNames = exts.data();

    if (vkCreateInstance(&ci, nullptr, &instance_) != VK_SUCCESS) throw std::runtime_error("vkCreateInstance failed");
}

void VulkanContext::setupDebug(){
    auto pfnCreate = (PFN_vkCreateDebugUtilsMessengerEXT)vkGetInstanceProcAddr(instance_, "vkCreateDebugUtilsMessengerEXT");
    if (!pfnCreate) return;
    VkDebugUtilsMessengerCreateInfoEXT info{ VK_STRUCTURE_TYPE_DEBUG_UTILS_MESSENGER_CREATE_INFO_EXT };
    info.messageSeverity = VK_DEBUG_UTILS_MESSAGE_SEVERITY_WARNING_BIT_EXT |
                           VK_DEBUG_UTILS_MESSAGE_SEVERITY_ERROR_BIT_EXT;
    info.messageType = VK_DEBUG_UTILS_MESSAGE_TYPE_GENERAL_BIT_EXT |
                       VK_DEBUG_UTILS_MESSAGE_TYPE_VALIDATION_BIT_EXT |
                       VK_DEBUG_UTILS_MESSAGE_TYPE_PERFORMANCE_BIT_EXT;
    info.pfnUserCallback = debugCallback;
    pfnCreate(instance_, &info, nullptr, &debugMessenger_);
}

VKAPI_ATTR VkBool32 VKAPI_CALL VulkanContext::debugCallback(
    VkDebugUtilsMessageSeverityFlagBitsEXT severity,
    VkDebugUtilsMessageTypeFlagsEXT types,
    const VkDebugUtilsMessengerCallbackDataEXT* pCallbackData,
    void* pUserData){
    std::cerr << "[VK] " << pCallbackData->pMessage << std::endl;
    return VK_FALSE;
}

void VulkanContext::pickPhysicalDevice(){
    uint32_t count=0; vkEnumeratePhysicalDevices(instance_, &count, nullptr);
    if (count==0) throw std::runtime_error("No physical devices");
    std::vector<VkPhysicalDevice> devs(count);
    vkEnumeratePhysicalDevices(instance_, &count, devs.data());

    // Simple scoring: discrete > integrated > others
    uint32_t best = 0; int bestScore=-1;
    for (uint32_t i=0;i<count;++i){
        VkPhysicalDeviceProperties props{}; vkGetPhysicalDeviceProperties(devs[i], &props);
        int score = 0;
        if (props.deviceType == VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU) score+=100;
        else if (props.deviceType == VK_PHYSICAL_DEVICE_TYPE_INTEGRATED_GPU) score+=50;
        // must have graphics queue
        uint32_t qCount=0; vkGetPhysicalDeviceQueueFamilyProperties(devs[i], &qCount, nullptr);
        std::vector<VkQueueFamilyProperties> qprops(qCount);
        vkGetPhysicalDeviceQueueFamilyProperties(devs[i], &qCount, qprops.data());
        bool hasGraphics=false, hasTransfer=false; uint32_t gfx=0, xfer=0;
        for (uint32_t j=0;j<qCount;++j){
            if (qprops[j].queueFlags & VK_QUEUE_GRAPHICS_BIT){ hasGraphics=true; gfx=j; }
            if ((qprops[j].queueFlags & VK_QUEUE_TRANSFER_BIT) && !(qprops[j].queueFlags & VK_QUEUE_GRAPHICS_BIT)){ hasTransfer=true; xfer=j; }
        }
        if (!hasGraphics) continue;
        if (score > bestScore){ bestScore=score; best=i; }
    }
    physical_ = devs[best];

    // Query API version
    VkPhysicalDeviceProperties props{}; vkGetPhysicalDeviceProperties(physical_, &props);
    feats_.apiMajor = VK_API_VERSION_MAJOR(props.apiVersion);
    feats_.apiMinor = VK_API_VERSION_MINOR(props.apiVersion);

    // Probe features via pNext chain
    VkPhysicalDeviceFeatures2 feats2{ VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2 };
    VkPhysicalDeviceTimelineSemaphoreFeatures tl{ VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_TIMELINE_SEMAPHORE_FEATURES };
    VkPhysicalDeviceSynchronization2Features sync2{ VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_SYNCHRONIZATION_2_FEATURES };
    VkPhysicalDeviceDescriptorIndexingFeatures di{ VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_DESCRIPTOR_INDEXING_FEATURES };
    VkPhysicalDeviceMaintenance4Features maint4{ VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_MAINTENANCE_4_FEATURES };

    feats2.pNext = &tl;
    tl.pNext = &sync2;
    sync2.pNext = &di;
    di.pNext = &maint4;

    vkGetPhysicalDeviceFeatures2(physical_, &feats2);

    feats_.hasTimeline = tl.timelineSemaphore == VK_TRUE;
    feats_.hasSync2 = (feats_.apiMajor > 1 || (feats_.apiMajor==1 && feats_.apiMinor>=3)) || (sync2.synchronization2==VK_TRUE);
    feats_.hasDescriptorIndexing = (di.descriptorBindingPartiallyBound ||
                                    di.runtimeDescriptorArray ||
                                    di.descriptorBindingVariableDescriptorCount);
    feats_.hasMaintenance4 = maint4.maintenance4 == VK_TRUE;
}

void VulkanContext::createDevice(){
    // Queue family discovery
    uint32_t qCount=0; vkGetPhysicalDeviceQueueFamilyProperties(physical_, &qCount, nullptr);
    std::vector<VkQueueFamilyProperties> qprops(qCount);
    vkGetPhysicalDeviceQueueFamilyProperties(physical_, &qCount, qprops.data());
    qf_.graphics = 0; qf_.transfer = 0; qf_.hasTransfer = false;
    for (uint32_t i=0;i<qCount;++i){
        if (qprops[i].queueFlags & VK_QUEUE_GRAPHICS_BIT) qf_.graphics = i;
    }
    for (uint32_t i=0;i<qCount;++i){
        if ((qprops[i].queueFlags & VK_QUEUE_TRANSFER_BIT) && !(qprops[i].queueFlags & VK_QUEUE_GRAPHICS_BIT)){
            qf_.transfer = i; qf_.hasTransfer = true; break;
        }
    }
    if (!qf_.hasTransfer) qf_.transfer = qf_.graphics;

    float prio = 1.0f;
    std::vector<VkDeviceQueueCreateInfo> qcis;
    VkDeviceQueueCreateInfo qgfx{ VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO };
    qgfx.queueFamilyIndex = qf_.graphics; qgfx.queueCount = 1; qgfx.pQueuePriorities = &prio;
    qcis.push_back(qgfx);
    if (qf_.transfer != qf_.graphics){
        VkDeviceQueueCreateInfo qx{ VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO };
        qx.queueFamilyIndex = qf_.transfer; qx.queueCount = 1; qx.pQueuePriorities = &prio;
        qcis.push_back(qx);
    }

    // Build feature chain (enable only if supported)
    VkPhysicalDeviceFeatures2 feats2{ VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2 };
    VkPhysicalDeviceTimelineSemaphoreFeatures tl{ VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_TIMELINE_SEMAPHORE_FEATURES };
    VkPhysicalDeviceSynchronization2Features sync2{ VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_SYNCHRONIZATION_2_FEATURES };
    VkPhysicalDeviceDescriptorIndexingFeatures di{ VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_DESCRIPTOR_INDEXING_FEATURES };
    VkPhysicalDeviceMaintenance4Features maint4{ VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_MAINTENANCE_4_FEATURES };
    feats2.pNext = &tl; tl.pNext = &sync2; sync2.pNext = &di; di.pNext = &maint4;
    tl.timelineSemaphore = feats_.hasTimeline ? VK_TRUE : VK_FALSE;
    sync2.synchronization2 = feats_.hasSync2 ? VK_TRUE : VK_FALSE;
    di.runtimeDescriptorArray = feats_.hasDescriptorIndexing ? VK_TRUE : VK_FALSE;
    di.descriptorBindingPartiallyBound = feats_.hasDescriptorIndexing ? VK_TRUE : VK_FALSE;
    di.descriptorBindingVariableDescriptorCount = feats_.hasDescriptorIndexing ? VK_TRUE : VK_FALSE;
    maint4.maintenance4 = feats_.hasMaintenance4 ? VK_TRUE : VK_FALSE;

    std::vector<const char*> exts;
    if (feats_.hasSync2) exts.push_back(VK_KHR_SYNCHRONIZATION_2_EXTENSION_NAME);
    if (feats_.hasTimeline) exts.push_back(VK_KHR_TIMELINE_SEMAPHORE_EXTENSION_NAME);
    if (feats_.hasDescriptorIndexing) exts.push_back(VK_EXT_DESCRIPTOR_INDEXING_EXTENSION_NAME);

    VkDeviceCreateInfo dci{ VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO };
    dci.pNext = &feats2;
    dci.queueCreateInfoCount = (uint32_t)qcis.size();
    dci.pQueueCreateInfos = qcis.data();
    dci.enabledExtensionCount = (uint32_t)exts.size();
    dci.ppEnabledExtensionNames = exts.empty() ? nullptr : exts.data();

    if (vkCreateDevice(physical_, &dci, nullptr, &device_) != VK_SUCCESS) throw std::runtime_error("vkCreateDevice failed");

    vkGetDeviceQueue(device_, qf_.graphics, 0, &graphicsQ_);
    vkGetDeviceQueue(device_, qf_.transfer, 0, &transferQ_);

    // load sync2 functions if available
    if (feats_.hasSync2){
        pfn_vkQueueSubmit2_ = (PFN_vkQueueSubmit2)vkGetDeviceProcAddr(device_, "vkQueueSubmit2");
        pfn_vkCmdPipelineBarrier2_ = (PFN_vkCmdPipelineBarrier2)vkGetDeviceProcAddr(device_, "vkCmdPipelineBarrier2");
    }
}

void VulkanContext::createPools(){
    VkCommandPoolCreateInfo pi{ VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO };
    pi.queueFamilyIndex = qf_.graphics;
    pi.flags = VK_COMMAND_POOL_CREATE_TRANSIENT_BIT | VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
    vkCreateCommandPool(device_, &pi, nullptr, &graphicsPool_);
    pi.queueFamilyIndex = qf_.transfer;
    vkCreateCommandPool(device_, &pi, nullptr, &transferPool_);
}

void VulkanContext::createDescriptorPool(){
    const uint32_t N = 2048;
    std::vector<VkDescriptorPoolSize> sizes = {
        { VK_DESCRIPTOR_TYPE_STORAGE_BUFFER, N },
        { VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE, N },
        { VK_DESCRIPTOR_TYPE_STORAGE_IMAGE, N },
        { VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER, N },
        { VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER, N }
    };
    VkDescriptorPoolCreateInfo ci{ VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO };
    ci.maxSets = N * 2;
    ci.poolSizeCount = (uint32_t)sizes.size();
    ci.pPoolSizes = sizes.data();
    if (feats_.hasDescriptorIndexing) ci.flags = VK_DESCRIPTOR_POOL_CREATE_UPDATE_AFTER_BIND_BIT;
    vkCreateDescriptorPool(device_, &ci, nullptr, &descPool_);
}

void VulkanContext::destroyPools(){
    if (graphicsPool_) { vkDestroyCommandPool(device_, graphicsPool_, nullptr); graphicsPool_=VK_NULL_HANDLE; }
    if (transferPool_) { vkDestroyCommandPool(device_, transferPool_, nullptr); transferPool_=VK_NULL_HANDLE; }
}

void VulkanContext::destroyDescriptorPool(){
    if (descPool_) { vkDestroyDescriptorPool(device_, descPool_, nullptr); descPool_=VK_NULL_HANDLE; }
}

void VulkanContext::destroyDevice(){
    if (device_){ vkDeviceWaitIdle(device_); vkDestroyDevice(device_, nullptr); device_=VK_NULL_HANDLE; }
}

void VulkanContext::destroyInstance(){
    if (instance_){ vkDestroyInstance(instance_, nullptr); instance_ = VK_NULL_HANDLE; }
}

uint32_t VulkanContext::findMemoryType(uint32_t typeBits, VkMemoryPropertyFlags props) const{
    VkPhysicalDeviceMemoryProperties mp{}; vkGetPhysicalDeviceMemoryProperties(physical_, &mp);
    for (uint32_t i=0;i<mp.memoryTypeCount;++i){
        if ((typeBits & (1u<<i)) && (mp.memoryTypes[i].propertyFlags & props) == props) return i;
    }
    throw std::runtime_error("No suitable memory type");
}

void VulkanContext::createBuffer(VkDeviceSize size, VkBufferUsageFlags usage, VkMemoryPropertyFlags props,
                                 VkBuffer& buffer, VkDeviceMemory& memory){
    VkBufferCreateInfo bi{ VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO };
    bi.size = size; bi.usage = usage; bi.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    if (vkCreateBuffer(device_, &bi, nullptr, &buffer) != VK_SUCCESS) throw std::runtime_error("createBuffer failed");
    VkMemoryRequirements req{}; vkGetBufferMemoryRequirements(device_, buffer, &req);
    VkMemoryAllocateInfo ai{ VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO };
    ai.allocationSize = req.size; ai.memoryTypeIndex = findMemoryType(req.memoryTypeBits, props);
    if (vkAllocateMemory(device_, &ai, nullptr, &memory) != VK_SUCCESS) throw std::runtime_error("alloc mem failed");
    vkBindBufferMemory(device_, buffer, memory, 0);
}

void VulkanContext::destroyBuffer(VkBuffer buf, VkDeviceMemory mem){
    if (buf) vkDestroyBuffer(device_, buf, nullptr);
    if (mem) vkFreeMemory(device_, mem, nullptr);
}

void VulkanContext::submitOneShot(uint32_t family, VkQueue queue, const std::function<void(VkCommandBuffer)>& record){
    VkCommandPool pool = (family == qf_.graphics) ? graphicsPool_ : transferPool_;
    VkCommandBufferAllocateInfo ai{ VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO };
    ai.commandPool = pool; ai.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY; ai.commandBufferCount = 1;
    VkCommandBuffer cmd; vkAllocateCommandBuffers(device_, &ai, &cmd);
    VkCommandBufferBeginInfo bi{ VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO };
    bi.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
    vkBeginCommandBuffer(cmd, &bi);
    record(cmd);
    vkEndCommandBuffer(cmd);

    if (feats_.hasSync2 && pfn_vkQueueSubmit2_){
        VkCommandBufferSubmitInfo cb{ VK_STRUCTURE_TYPE_COMMAND_BUFFER_SUBMIT_INFO };
        cb.commandBuffer = cmd;
        VkSubmitInfo2 s{ VK_STRUCTURE_TYPE_SUBMIT_INFO_2 };
        s.commandBufferInfoCount = 1; s.pCommandBufferInfos = &cb;
        pfn_vkQueueSubmit2_(queue, 1, &s, VK_NULL_HANDLE);
    } else {
        VkSubmitInfo s{ VK_STRUCTURE_TYPE_SUBMIT_INFO };
        s.commandBufferCount = 1; s.pCommandBuffers = &cmd;
        vkQueueSubmit(queue, 1, &s, VK_NULL_HANDLE);
    }
    vkQueueWaitIdle(queue);
    vkFreeCommandBuffers(device_, pool, 1, &cmd);
}

VkSemaphore VulkanContext::createTimelineSemaphore(uint64_t initialValue){
    if (!feats_.hasTimeline) return VK_NULL_HANDLE;
    VkSemaphoreTypeCreateInfo type{ VK_STRUCTURE_TYPE_SEMAPHORE_TYPE_CREATE_INFO };
    type.semaphoreType = VK_SEMAPHORE_TYPE_TIMELINE; type.initialValue = initialValue;
    VkSemaphoreCreateInfo ci{ VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO };
    ci.pNext = &type;
    VkSemaphore sem;
    if (vkCreateSemaphore(device_, &ci, nullptr, &sem) != VK_SUCCESS) return VK_NULL_HANDLE;
    return sem;
}

void VulkanContext::waitTimeline(VkSemaphore sem, uint64_t value){
    if (!feats_.hasTimeline || sem==VK_NULL_HANDLE) return;
    VkSemaphoreWaitInfo wi{ VK_STRUCTURE_TYPE_SEMAPHORE_WAIT_INFO };
    wi.flags = 0; wi.semaphoreCount = 1; wi.pSemaphores = &sem; wi.pValues = &value;
    vkWaitSemaphores(device_, &wi, UINT64_MAX);
}

void VulkanContext::signalTimeline(VkQueue queue, VkSemaphore sem, uint64_t value){
    if (!feats_.hasTimeline || sem==VK_NULL_HANDLE) return;
    if (feats_.hasSync2 && pfn_vkQueueSubmit2_){
        VkSemaphoreSubmitInfo sig{ VK_STRUCTURE_TYPE_SEMAPHORE_SUBMIT_INFO };
        sig.semaphore = sem; sig.value = value; sig.stageMask = VK_PIPELINE_STAGE_2_ALL_COMMANDS_BIT; sig.deviceIndex = 0;
        VkSubmitInfo2 s{ VK_STRUCTURE_TYPE_SUBMIT_INFO_2 };
        s.signalSemaphoreInfoCount = 1; s.pSignalSemaphoreInfos = &sig;
        pfn_vkQueueSubmit2_(queue, 1, &s, VK_NULL_HANDLE);
    } else {
        // Fallback by submitting an empty batch with a timeline signal using legacy path is not supported;
        // simply wait on device idle as a coarse fallback.
        vkQueueWaitIdle(queue);
    }
}

void VulkanContext::transferComputeTransferChain(
    const std::function<void(VkCommandBuffer)>& recordCopyUp,
    const std::function<void(VkCommandBuffer)>& recordCompute,
    const std::function<void(VkCommandBuffer)>& recordCopyDown)
{
    VkSemaphore timeline = createTimelineSemaphore(0);
    uint64_t v0=1, v1=2, v2=3;

    // Allocate three command buffers
    VkCommandBufferAllocateInfo ai{ VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO };
    ai.commandBufferCount = 1; ai.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;

    ai.commandPool = transferPool_;
    VkCommandBuffer cmdUp; vkAllocateCommandBuffers(device_, &ai, &cmdUp);
    ai.commandPool = graphicsPool_;
    VkCommandBuffer cmdCompute; vkAllocateCommandBuffers(device_, &ai, &cmdCompute);
    ai.commandPool = transferPool_;
    VkCommandBuffer cmdDown; vkAllocateCommandBuffers(device_, &ai, &cmdDown);

    auto begin = [&](VkCommandBuffer cmd){
        VkCommandBufferBeginInfo bi{ VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO };
        bi.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
        vkBeginCommandBuffer(cmd, &bi);
    };
    begin(cmdUp); recordCopyUp(cmdUp); vkEndCommandBuffer(cmdUp);
    begin(cmdCompute); recordCompute(cmdCompute); vkEndCommandBuffer(cmdCompute);
    begin(cmdDown); recordCopyDown(cmdDown); vkEndCommandBuffer(cmdDown);

    if (feats_.hasSync2 && pfn_vkQueueSubmit2_){
        // Up submit (signal timeline=1)
        VkCommandBufferSubmitInfo cbUp{ VK_STRUCTURE_TYPE_COMMAND_BUFFER_SUBMIT_INFO }; cbUp.commandBuffer = cmdUp;
        VkSemaphoreSubmitInfo sigUp{ VK_STRUCTURE_TYPE_SEMAPHORE_SUBMIT_INFO };
        sigUp.semaphore = timeline; sigUp.value = v0; sigUp.stageMask = VK_PIPELINE_STAGE_2_ALL_COMMANDS_BIT;

        VkSubmitInfo2 subUp{ VK_STRUCTURE_TYPE_SUBMIT_INFO_2 };
        subUp.commandBufferInfoCount = 1; subUp.pCommandBufferInfos = &cbUp;
        subUp.signalSemaphoreInfoCount = 1; subUp.pSignalSemaphoreInfos = &sigUp;
        pfn_vkQueueSubmit2_(transferQueue(), 1, &subUp, VK_NULL_HANDLE);

        // Compute submit (wait=1, signal=2)
        VkSemaphoreSubmitInfo waitCompute{ VK_STRUCTURE_TYPE_SEMAPHORE_SUBMIT_INFO };
        waitCompute.semaphore = timeline; waitCompute.value = v0; waitCompute.stageMask = VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT;
        VkSemaphoreSubmitInfo sigCompute{ VK_STRUCTURE_TYPE_SEMAPHORE_SUBMIT_INFO };
        sigCompute.semaphore = timeline; sigCompute.value = v1; sigCompute.stageMask = VK_PIPELINE_STAGE_2_ALL_COMMANDS_BIT;
        VkCommandBufferSubmitInfo cbCompute{ VK_STRUCTURE_TYPE_COMMAND_BUFFER_SUBMIT_INFO }; cbCompute.commandBuffer = cmdCompute;
        VkSubmitInfo2 subCompute{ VK_STRUCTURE_TYPE_SUBMIT_INFO_2 };
        subCompute.waitSemaphoreInfoCount = 1; subCompute.pWaitSemaphoreInfos = &waitCompute;
        subCompute.commandBufferInfoCount = 1; subCompute.pCommandBufferInfos = &cbCompute;
        subCompute.signalSemaphoreInfoCount = 1; subCompute.pSignalSemaphoreInfos = &sigCompute;
        pfn_vkQueueSubmit2_(graphicsQueue(), 1, &subCompute, VK_NULL_HANDLE);

        // Down submit (wait=2, signal=3)
        VkSemaphoreSubmitInfo waitDown{ VK_STRUCTURE_TYPE_SEMAPHORE_SUBMIT_INFO };
        waitDown.semaphore = timeline; waitDown.value = v1; waitDown.stageMask = VK_PIPELINE_STAGE_2_ALL_COMMANDS_BIT;
        VkSemaphoreSubmitInfo sigDown{ VK_STRUCTURE_TYPE_SEMAPHORE_SUBMIT_INFO };
        sigDown.semaphore = timeline; sigDown.value = v2; sigDown.stageMask = VK_PIPELINE_STAGE_2_ALL_COMMANDS_BIT;
        VkCommandBufferSubmitInfo cbDown{ VK_STRUCTURE_TYPE_COMMAND_BUFFER_SUBMIT_INFO }; cbDown.commandBuffer = cmdDown;
        VkSubmitInfo2 subDown{ VK_STRUCTURE_TYPE_SUBMIT_INFO_2 };
        subDown.waitSemaphoreInfoCount = 1; subDown.pWaitSemaphoreInfos = &waitDown;
        subDown.commandBufferInfoCount = 1; subDown.pCommandBufferInfos = &cbDown;
        subDown.signalSemaphoreInfoCount = 1; subDown.pSignalSemaphoreInfos = &sigDown;
        pfn_vkQueueSubmit2_(transferQueue(), 1, &subDown, VK_NULL_HANDLE);

        // Wait for v2
        waitTimeline(timeline, v2);
    } else {
        // Legacy fallback: serial submits per-queue and device idle waits
        submitOneShot(qf_.transfer, transferQueue(), [&](VkCommandBuffer){ /* already recorded */ });
        submitOneShot(qf_.graphics, graphicsQueue(), [&](VkCommandBuffer){ /* already recorded */ });
        submitOneShot(qf_.transfer, transferQueue(), [&](VkCommandBuffer){ /* already recorded */ });
    }

    vkFreeCommandBuffers(device_, transferPool_, 1, &cmdUp);
    vkFreeCommandBuffers(device_, graphicsPool_, 1, &cmdCompute);
    vkFreeCommandBuffers(device_, transferPool_, 1, &cmdDown);
    if (timeline) vkDestroySemaphore(device_, timeline, nullptr);
}

} // namespace voxelvk


#pragma once
#include <string>
#include <vector>
#include <optional>

namespace voxelvk {

// Extremely small, allow-listed DSL: map key=value pairs separated by commas.
// Example: select keys a,b,c | rename a->x,b->y
struct TransformResult { bool ok; std::string message; };

class TransformDSL {
public:
    static TransformResult apply(const std::string& dsl, const std::string& input_json, std::string& output_json);
};

} // namespace voxelvk

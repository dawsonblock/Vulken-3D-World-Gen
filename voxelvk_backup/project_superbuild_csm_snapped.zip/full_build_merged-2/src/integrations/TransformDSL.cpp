
#include "TransformDSL.hpp"
#include <sstream>

using namespace voxelvk;

static bool is_safe_char(char c) {
    return std::isalnum(static_cast<unsigned char>(c)) || c=='_' || c=='-' || c==',' || c=='>' || c==':' || c==' ' || c=='{' || c=='}' || c=='[' || c==']' || c=='"' || c=='
';
}

TransformResult TransformDSL::apply(const std::string& dsl, const std::string& input_json, std::string& output_json) {
    for (char c : dsl) if (!is_safe_char(c)) return {false, std::string("Rejected unsafe char")};
    // Placeholder: identity transform. Replace with real parser as needed.
    output_json = input_json;
    return {true, std::string("ok")};
}


#include "Metrics.hpp"
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <cstring>

using namespace voxelvk;

void MetricsRegistry::inc(const std::string& name) {
    std::lock_guard<std::mutex> lk(mtx_);
    vals_[name] += 1.0;
}

void MetricsRegistry::set(const std::string& name, double v) {
    std::lock_guard<std::mutex> lk(mtx_);
    vals_[name] = v;
}

std::string MetricsRegistry::render_prom() const {
    std::lock_guard<std::mutex> lk(mtx_);
    std::string out;
    for (auto &kv : vals_) {
        out += kv.first + std::string(" ") + std::to_string(kv.second) + std::string("
");
    }
    return out;
}

MetricsServer::MetricsServer() {}
MetricsServer::~MetricsServer() { stop(); }

void MetricsServer::start(unsigned short port) {
    if (running_) return;
    running_ = true;
    th_ = std::thread([this, port]() {
        int server_fd = socket(AF_INET, SOCK_STREAM, 0);
        if (server_fd < 0) return;
        int opt = 1;
        setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt));
        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = htonl(INADDR_ANY);
        addr.sin_port = htons(port);
        if (bind(server_fd, (sockaddr*)&addr, sizeof(addr)) < 0) { close(server_fd); return; }
        if (listen(server_fd, 8) < 0) { close(server_fd); return; }
        while (running_) {
            int client = accept(server_fd, nullptr, nullptr);
            if (client < 0) continue;
            std::string body = render_prom();
            std::string resp = std::string("HTTP/1.1 200 OK
Content-Type: text/plain
Content-Length: ") + std::to_string(body.size()) + std::string("

") + body;
            send(client, resp.data(), resp.size(), 0);
            close(client);
        }
        close(server_fd);
    });
}

void MetricsServer::stop() {
    if (!running_) return;
    running_ = false;
    if (th_.joinable()) th_.join();
}

MetricsRegistry& MetricsServer::registry() { return reg_; }

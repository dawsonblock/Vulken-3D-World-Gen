
#pragma once
#include <atomic>
#include <thread>
#include <string>
#include <unordered_map>
#include <mutex>

namespace voxelvk {

class MetricsRegistry {
public:
    void inc(const std::string& name);
    void set(const std::string& name, double v);
    std::string render_prom() const;
private:
    mutable std::mutex mtx_;
    std::unordered_map<std::string, double> vals_;
};

class MetricsServer {
public:
    MetricsServer();
    ~MetricsServer();
    void start(unsigned short port = 9090);
    void stop();
    MetricsRegistry& registry();
private:
    MetricsRegistry reg_;
    std::thread th_;
    std::atomic<bool> running_{false};
};

} // namespace voxelvk

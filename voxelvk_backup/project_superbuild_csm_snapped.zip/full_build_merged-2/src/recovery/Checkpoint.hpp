
#pragma once
#include <string>
#include <vector>

namespace voxelvk {

class CheckpointIO {
public:
    bool save(const std::string& file, const std::vector<std::pair<std::string,std::string>>& kv);
    bool load(const std::string& file, std::vector<std::pair<std::string,std::string>>& kv);
};

} // namespace voxelvk


#include "Checkpoint.hpp"
#include <fstream>

using namespace voxelvk;

bool CheckpointIO::save(const std::string& file, const std::vector<std::pair<std::string,std::string>>& kv) {
    std::ofstream out(file);
    if (!out.good()) return false;
    for (auto &p : kv) out << p.first << "=" << p.second << "
";
    return true;
}

bool CheckpointIO::load(const std::string& file, std::vector<std::pair<std::string,std::string>>& kv) {
    std::ifstream in(file);
    if (!in.good()) return false;
    std::string line;
    while (std::getline(in, line)) {
        auto pos = line.find('=');
        if (pos == std::string::npos) continue;
        kv.push_back({ line.substr(0,pos), line.substr(pos+1) });
    }
    return true;
}

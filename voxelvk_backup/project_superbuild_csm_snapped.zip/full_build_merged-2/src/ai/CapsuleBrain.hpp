
#pragma once
#include <string>
#include <atomic>
#include <thread>
#include "../core/Async.hpp"
#include "../memory/Memory.hpp"
#include "Providers.hpp"

namespace voxelvk {

class CapsuleBrain {
public:
    CapsuleBrain();
    ~CapsuleBrain();
    void start();
    void stop();
    void submit_goal(const std::string& goal);
private:
    ThreadPool pool_;
    MemoryStore memory_;
    LocalProvider local_;
    std::atomic<bool> running_{false};
    std::thread proactive_;
};

} // namespace voxelvk

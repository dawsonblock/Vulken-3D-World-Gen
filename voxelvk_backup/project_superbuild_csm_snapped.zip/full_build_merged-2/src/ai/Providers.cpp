#include "Providers.hpp"
using namespace voxelvk;

AIResponse LocalProvider::complete(const std::string& prompt){
    return AIResponse{ std::string("[local] ") + prompt };
}

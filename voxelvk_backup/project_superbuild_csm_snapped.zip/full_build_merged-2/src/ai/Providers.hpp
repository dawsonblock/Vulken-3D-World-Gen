#pragma once
#include <string>

namespace voxelvk {

struct AIResponse { std::string text; };

class LocalProvider {
public:
    AIResponse complete(const std::string& prompt);
};

} // namespace voxelvk

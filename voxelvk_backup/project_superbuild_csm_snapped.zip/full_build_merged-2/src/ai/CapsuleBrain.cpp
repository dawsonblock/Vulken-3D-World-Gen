#include "CapsuleBrain.hpp"
#include <iostream>
#include <chrono>
#include <thread>

using namespace voxelvk;

CapsuleBrain::CapsuleBrain() {}
CapsuleBrain::~CapsuleBrain(){ stop(); }

void CapsuleBrain::start(){
    if (running_) return;
    running_ = true;
    proactive_ = std::thread([this](){
        while (running_) {
            memory_.decay(0.999);
            std::this_thread::sleep_for(std::chrono::milliseconds(50));
        }
    });
}

void CapsuleBrain::stop(){
    if (!running_) return;
    running_ = false;
    if (proactive_.joinable()) proactive_.join();
    pool_.shutdown();
}

void CapsuleBrain::submit_goal(const std::string& goal){
    memory_.put("last_goal", goal);
    auto fut = pool_.submit([this, goal](){
        auto r = local_.complete(std::string("Plan: ") + goal);
        std::cout << r.text << std::endl;
    });
    fut.wait();
}

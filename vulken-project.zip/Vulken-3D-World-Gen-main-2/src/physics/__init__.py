"""Physics simulation components."""

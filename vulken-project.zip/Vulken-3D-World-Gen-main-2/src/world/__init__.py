"""World persistence utilities."""
